﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class SubjectDataEditForm : Form
    {
        string[] editedInfoList;
        int subjectID, TeacherID, type_ID;
        string uniqueSubjectName, teacherName, teacherSurname, subject_name;
        AdminPanel adminPanel;
        DataGridView dataGrid;
        Database db = new Database();

        private void SubjectList_SelectedIndexChanged(object sender, EventArgs e)
        {
            editedInfoList[1] = SubjectList.Text.Split(' ')[0];
        }

        private void TeacherList_SelectedIndexChanged(object sender, EventArgs e)
        {
            editedInfoList[0] = TeacherList.Text.Split(' ')[0];
        }

        public SubjectDataEditForm(AdminPanel _adminPanel, DataGridView _dataGrid, int _subjectID, int _TeacherID, int _type_ID, string _UniqueName, string _name, string _surname, string _subject_name)
        {
            InitializeComponent();
            adminPanel = _adminPanel;
            dataGrid = _dataGrid;
            subjectID = _subjectID;
            TeacherID = _TeacherID;
            uniqueSubjectName = _UniqueName;
            type_ID = _type_ID;
            teacherName = _name;
            teacherSurname = _surname;
            subject_name = _subject_name;

            UniqueSubjectName.Text = uniqueSubjectName;
            editedInfoList = new string[4];

            PopulateLists();
        }

        private void PopulateLists()
        {
            string query;
            MySqlCommand userCommand;
            MySqlConnection connection;
            MySqlDataReader dataReader;

            connection = db.GetConnectionToDatabase();

            for (int i = 0; i < 2; i++)
            {
                db.OpenConnectionToDatabase();

                query = i == 0 ? "SELECT Subject_Type_ID, Name from subject_type" : "SELECT Teacher_ID, Name, Surname from teachers";
                userCommand = new MySqlCommand(query, connection);

                try
                {
                    dataReader = userCommand.ExecuteReader();
                    while (dataReader.Read())
                    {
                        if (i == 0)
                        {
                            SubjectList.Items.Add(dataReader.GetString(0) + " " + dataReader.GetString(1));
                        }
                        else
                        {
                            TeacherList.Items.Add(dataReader.GetString(0) + " " + dataReader.GetString(1) + " " + dataReader.GetString(2));
                        }
                    }
                    dataReader.Close();

                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
                finally
                {
                    db.CloseConnectionToDatabase();
                }
            }

            TeacherList.Text = TeacherID.ToString() + " " + teacherName + " " + teacherSurname;
            SubjectList.Text = type_ID.ToString() + " " + subject_name;
            editedInfoList[0] = TeacherList.Text.Split(' ')[0];
            editedInfoList[1] = SubjectList.Text.Split(' ')[0];
        }

        private void SaveSubjectInfoButton_Click(object sender, EventArgs e)
        {
            string[] inputFields = { subject_name, UniqueSubjectName.Text };
            if (InputFieldManager.CheckForEmptyInputFields(inputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            MySqlConnection connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            try
            {
                MySqlCommand command = new MySqlCommand("update subject set Subject_Type_ID = @typeID, Teacher_ID = @teacherID, Subject_Name = @subjectName, Unique_Subject_Name = @unique_name where subject_ID = @id", connection);
                command.Parameters.AddWithValue("@typeID", Convert.ToInt32(editedInfoList[1]));
                command.Parameters.AddWithValue("@teacherID", Convert.ToInt32(editedInfoList[0]));
                command.Parameters.AddWithValue("@subjectName", subject_name);
                command.Parameters.AddWithValue("@unique_name", UniqueSubjectName.Text);
                command.Parameters.AddWithValue("@id", subjectID);

                int executionResult = command.ExecuteNonQuery();

                if (executionResult > 0)
                {
                    adminPanel.UpdateGrid(dataGrid, "SELECT subject.Teacher_ID, subject.Subject_Type_ID, subject.Subject_ID, subject_type.Name as subjectName, teachers.Name, teachers.Surname, " +
                    "subject.Unique_Subject_Name from subject INNER JOIN teachers on subject.Teacher_ID = teachers.Teacher_ID inner join subject_type on subject.Subject_Type_ID = subject_type.Subject_Type_ID");

                    MessageBox.Show("Sėkimingai išsaugota");
                }
                else
                {
                    MessageBox.Show("Įvyko klaida");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
                this.Close();
            }
        }
    }
}
