﻿
namespace APP
{
    partial class TeacherDataEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddStudentPanel = new System.Windows.Forms.Panel();
            this.TeacherEmailText = new System.Windows.Forms.TextBox();
            this.TeacherEmailTxt = new System.Windows.Forms.TextBox();
            this.SaveTeacherDataChanges_Button = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.TeacherPhoneText = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.TeacherAddressText = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.TeacherSurnameText = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.TeacherNameText = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.AddStudentPanel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddStudentPanel
            // 
            this.AddStudentPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.AddStudentPanel.Controls.Add(this.TeacherEmailText);
            this.AddStudentPanel.Controls.Add(this.TeacherEmailTxt);
            this.AddStudentPanel.Controls.Add(this.SaveTeacherDataChanges_Button);
            this.AddStudentPanel.Controls.Add(this.textBox11);
            this.AddStudentPanel.Controls.Add(this.TeacherPhoneText);
            this.AddStudentPanel.Controls.Add(this.textBox9);
            this.AddStudentPanel.Controls.Add(this.TeacherAddressText);
            this.AddStudentPanel.Controls.Add(this.textBox7);
            this.AddStudentPanel.Controls.Add(this.TeacherSurnameText);
            this.AddStudentPanel.Controls.Add(this.textBox6);
            this.AddStudentPanel.Controls.Add(this.TeacherNameText);
            this.AddStudentPanel.Controls.Add(this.panel5);
            this.AddStudentPanel.Location = new System.Drawing.Point(1, 0);
            this.AddStudentPanel.Name = "AddStudentPanel";
            this.AddStudentPanel.Size = new System.Drawing.Size(290, 477);
            this.AddStudentPanel.TabIndex = 7;
            // 
            // TeacherEmailText
            // 
            this.TeacherEmailText.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TeacherEmailText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TeacherEmailText.Location = new System.Drawing.Point(23, 209);
            this.TeacherEmailText.Name = "TeacherEmailText";
            this.TeacherEmailText.Size = new System.Drawing.Size(100, 16);
            this.TeacherEmailText.TabIndex = 17;
            this.TeacherEmailText.Text = "El. pašto adresas:";
            // 
            // TeacherEmailTxt
            // 
            this.TeacherEmailTxt.Location = new System.Drawing.Point(23, 231);
            this.TeacherEmailTxt.Multiline = true;
            this.TeacherEmailTxt.Name = "TeacherEmailTxt";
            this.TeacherEmailTxt.Size = new System.Drawing.Size(242, 28);
            this.TeacherEmailTxt.TabIndex = 16;
            // 
            // SaveTeacherDataChanges_Button
            // 
            this.SaveTeacherDataChanges_Button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SaveTeacherDataChanges_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveTeacherDataChanges_Button.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SaveTeacherDataChanges_Button.ForeColor = System.Drawing.SystemColors.Control;
            this.SaveTeacherDataChanges_Button.Location = new System.Drawing.Point(48, 416);
            this.SaveTeacherDataChanges_Button.Name = "SaveTeacherDataChanges_Button";
            this.SaveTeacherDataChanges_Button.Size = new System.Drawing.Size(185, 47);
            this.SaveTeacherDataChanges_Button.TabIndex = 13;
            this.SaveTeacherDataChanges_Button.Text = "Išsaugoti Pakeitimus";
            this.SaveTeacherDataChanges_Button.UseVisualStyleBackColor = false;
            this.SaveTeacherDataChanges_Button.Click += new System.EventHandler(this.SaveTeacherDataChanges_Button_Click);
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Location = new System.Drawing.Point(23, 341);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 16);
            this.textBox11.TabIndex = 11;
            this.textBox11.Text = "Telefono Nr.:";
            // 
            // TeacherPhoneText
            // 
            this.TeacherPhoneText.Location = new System.Drawing.Point(23, 360);
            this.TeacherPhoneText.Multiline = true;
            this.TeacherPhoneText.Name = "TeacherPhoneText";
            this.TeacherPhoneText.Size = new System.Drawing.Size(242, 28);
            this.TeacherPhoneText.TabIndex = 10;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Location = new System.Drawing.Point(23, 279);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 16);
            this.textBox9.TabIndex = 9;
            this.textBox9.Text = "Adresas:";
            // 
            // TeacherAddressText
            // 
            this.TeacherAddressText.Location = new System.Drawing.Point(23, 298);
            this.TeacherAddressText.Multiline = true;
            this.TeacherAddressText.Name = "TeacherAddressText";
            this.TeacherAddressText.Size = new System.Drawing.Size(242, 28);
            this.TeacherAddressText.TabIndex = 8;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Location = new System.Drawing.Point(23, 144);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 16);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "Pavardė:";
            // 
            // TeacherSurnameText
            // 
            this.TeacherSurnameText.Location = new System.Drawing.Point(23, 163);
            this.TeacherSurnameText.Multiline = true;
            this.TeacherSurnameText.Name = "TeacherSurnameText";
            this.TeacherSurnameText.Size = new System.Drawing.Size(242, 28);
            this.TeacherSurnameText.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Location = new System.Drawing.Point(24, 88);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 16);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "Vardas:";
            // 
            // TeacherNameText
            // 
            this.TeacherNameText.Location = new System.Drawing.Point(24, 107);
            this.TeacherNameText.Multiline = true;
            this.TeacherNameText.Name = "TeacherNameText";
            this.TeacherNameText.Size = new System.Drawing.Size(241, 28);
            this.TeacherNameText.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.textBox4);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(287, 68);
            this.panel5.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Location = new System.Drawing.Point(3, 16);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(287, 38);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Atnaujinti Informaciją";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TeacherDataEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 475);
            this.Controls.Add(this.AddStudentPanel);
            this.Name = "TeacherDataEditForm";
            this.Text = "Redagavimo langas";
            this.AddStudentPanel.ResumeLayout(false);
            this.AddStudentPanel.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel AddStudentPanel;
        private System.Windows.Forms.Button SaveTeacherDataChanges_Button;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox TeacherPhoneText;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox TeacherAddressText;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox TeacherSurnameText;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox TeacherNameText;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox TeacherEmailText;
        private System.Windows.Forms.TextBox TeacherEmailTxt;
    }
}