﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class NewGroupForm : Form
    {
        private string[] groupInfo;
        private Database db = new Database();
        private AdminPanel adminPanel;
        private DataGridView dataGrid;

        public NewGroupForm(AdminPanel _adminPanel, DataGridView _dataGrid)
        {
            InitializeComponent();
            adminPanel = _adminPanel;
            dataGrid = _dataGrid;
            groupInfo = new string[4];

            PopulateLists();
        }

        private void AddSubjectButton_Click(object sender, EventArgs e)
        {
            UserAccountManager userManager = new UserAccountManager();
            userManager.AddGroupToDatabase(groupInfo[0], groupInfo[1], groupInfo[2], StartingYearText.Text, groupInfo[3]);
            adminPanel.UpdateGrid(dataGrid, "select subject_group.Subject_Group_ID, students.Name, students.Surname, subject.Subject_Name, subject.Unique_Subject_Name, " +
                "subject_group.Year from subject_group Inner join students on subject_group.Student_ID = students.Student_ID inner join subject on subject.Subject_ID = subject_group.Subject_ID");
            this.Close();
        }

        private void PopulateLists()
        {
            string query;
            MySqlCommand userCommand;
            MySqlConnection connection;
            MySqlDataReader dataReader;

            connection = db.GetConnectionToDatabase();

            for (int i = 0; i < 2; i++)
            {
                db.OpenConnectionToDatabase();

                query = i == 0 ? "SELECT Student_ID, Name, Surname from students" : "SELECT Subject_ID, Unique_Subject_Name, Subject_Name from subject";
                userCommand = new MySqlCommand(query, connection);

                try
                {
                    dataReader = userCommand.ExecuteReader();
                    while (dataReader.Read())
                    {
                        if (i == 0)
                        {
                            StudentList.Items.Add(dataReader.GetString(0) + ". " + dataReader.GetString(1) + " " + dataReader.GetString(2));
                        }
                        else
                        {
                            SubjectList.Items.Add(dataReader.GetString(0) + ". " + dataReader.GetString(1) + " (" + dataReader.GetString(2) + ")");
                        }
                    }
                    dataReader.Close();

                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
                finally
                {
                    db.CloseConnectionToDatabase();
                }
            }
        }

        private void StudentList_SelectedIndexChanged(object sender, EventArgs e)
        {
            MySqlCommand userCommand;
            MySqlConnection connection;
            MySqlDataReader dataReader;

            connection = db.GetConnectionToDatabase();

            userCommand = new MySqlCommand("Select Student_ID, User_ID from students where Student_ID = @id", connection);

            userCommand.Parameters.AddWithValue("@id", SplitString(StudentList.Text)[0]);

            try
            {
                db.OpenConnectionToDatabase();

                dataReader = userCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    groupInfo[0] = dataReader.GetInt32(0).ToString();
                    groupInfo[1] = dataReader.GetInt32(1).ToString();
                }

                dataReader.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
            }
        }

        private void SubjectList_SelectedIndexChanged(object sender, EventArgs e)
        {
            MySqlCommand userCommand;
            MySqlConnection connection;
            MySqlDataReader dataReader;

            connection = db.GetConnectionToDatabase();

            string query = "Select Subject_ID, Unique_Subject_Name from subject where Subject_ID = " + SplitString(SubjectList.Text)[0];
            userCommand = new MySqlCommand(query, connection);

            try
            {
                db.OpenConnectionToDatabase();

                dataReader = userCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    groupInfo[2] = dataReader.GetString(0);
                    groupInfo[3] = dataReader.GetString(1);
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
            }
        }

        private string[] SplitString(string selectedString)
        {
            return selectedString.Split(' ');
        }
    }
}
