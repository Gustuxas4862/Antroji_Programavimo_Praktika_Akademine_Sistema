﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class StudentGradeEditForm : Form
    {
        private string grade, comment, date;
        private int[] grades = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        private int gradeID, teacherID;
        Database db = new Database();
        MySqlConnection connection;
        private DataGridView grid;
        private TeacherPanel teacherPanel;

        public StudentGradeEditForm(TeacherPanel _panel, DataGridView _grid, int _gradesID, int _teacherID, string _grade, string _comment, string _date)
        {
            InitializeComponent();

            teacherPanel = _panel;
            grid = _grid;
            gradeID = _gradesID;
            teacherID = _teacherID;
            grade = _grade;
            comment = _comment;
            date = _date;

            for (int i = 0; i < grades.Length; i++)
            {
                GradeList.Items.Add(grades[i]);
            }

            GradeList.Text = grade;
            CommentBox.Text = comment;
            DateBox.Text = date;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            string[] formInputFields = { DateBox.Text, GradeList.Text, CommentBox.Text };
            if (InputFieldManager.CheckForEmptyInputFields(formInputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            try
            {
                MySqlCommand command = new MySqlCommand("update grades set Grade = @grade, Comment = @comment, Date = @date where Grades_ID = @id", connection);
                command.Parameters.AddWithValue("@grade", GradeList.Text);
                command.Parameters.AddWithValue("@comment", CommentBox.Text);
                command.Parameters.AddWithValue("@date", DateBox.Text);
                command.Parameters.AddWithValue("@id", gradeID);

                int executionResult = command.ExecuteNonQuery();

                if (executionResult > 0)
                {
                    teacherPanel.UpdateGrid(grid, "SELECT grades.Grades_ID, grades.Group_ID, grades.Student_ID, grades.Subject_ID, students.Name, students.Surname, grades.Grade, grades.Date, grades.Comment from grades inner join students on students.Student_ID = grades.Student_ID where grades.Student_ID in (select subject_group.Student_ID from subject_group where subject_group.Subject_ID in (select subject.Subject_ID from subject where subject.Teacher_ID = " + teacherID + "))");

                    MessageBox.Show("Sėkimingai išsaugota");
                }
                else
                {
                    MessageBox.Show("Įvyko klaida");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
                this.Close();
            }
        }
    }
}
