﻿
namespace APP
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LogOutButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Group_Button = new System.Windows.Forms.Button();
            this.Subject_Button = new System.Windows.Forms.Button();
            this.StudentPanelButton = new System.Windows.Forms.Button();
            this.TeacherPanelButton = new System.Windows.Forms.Button();
            this.TeachersPanel = new System.Windows.Forms.Panel();
            this.AddTeacherButton = new System.Windows.Forms.Button();
            this.TeacherGrid = new System.Windows.Forms.DataGridView();
            this.GlobalUserID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Teacher_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserSurname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FullAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewButtonColumn2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Global_User_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.User_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.User_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Surname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Year = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TeacherDeleteButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.StudentPanel = new System.Windows.Forms.Panel();
            this.StudentGrid = new System.Windows.Forms.DataGridView();
            this.Student_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Student_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentSurnameData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentPhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Start_Year = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn3 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewButtonColumn4 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.AddStudentButton = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.StudentID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Student_User_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SurnameName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentSurname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentPhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ištrinti = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Redaguoti = new System.Windows.Forms.DataGridViewButtonColumn();
            this.SubjectPanel = new System.Windows.Forms.Panel();
            this.AddGroup = new System.Windows.Forms.Button();
            this.SubjectGrid = new System.Windows.Forms.DataGridView();
            this.Subject_Teacher_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subject_Type_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subject_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subject_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Teacher_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Teacher_Surname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unique_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn5 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewButtonColumn6 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.GroupsPanel = new System.Windows.Forms.Panel();
            this.AddGroup_Button = new System.Windows.Forms.Button();
            this.GroupGrid = new System.Windows.Forms.DataGridView();
            this.Group_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Student_Surname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Group_Subject_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Group_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Starting_Year = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Delete_Group = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Edit_Group = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.TeachersPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TeacherGrid)).BeginInit();
            this.panel3.SuspendLayout();
            this.StudentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StudentGrid)).BeginInit();
            this.panel5.SuspendLayout();
            this.SubjectPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SubjectGrid)).BeginInit();
            this.panel6.SuspendLayout();
            this.GroupsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GroupGrid)).BeginInit();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.LogOutButton);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1184, 59);
            this.panel1.TabIndex = 0;
            // 
            // LogOutButton
            // 
            this.LogOutButton.Location = new System.Drawing.Point(1056, 14);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(105, 33);
            this.LogOutButton.TabIndex = 1;
            this.LogOutButton.Text = "Atsijungti";
            this.LogOutButton.UseVisualStyleBackColor = true;
            this.LogOutButton.Click += new System.EventHandler(this.LogOutButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(458, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Administratoriaus valdymo langas";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.Group_Button);
            this.panel2.Controls.Add(this.Subject_Button);
            this.panel2.Controls.Add(this.StudentPanelButton);
            this.panel2.Controls.Add(this.TeacherPanelButton);
            this.panel2.Location = new System.Drawing.Point(-1, 49);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(183, 502);
            this.panel2.TabIndex = 1;
            // 
            // Group_Button
            // 
            this.Group_Button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Group_Button.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Group_Button.FlatAppearance.BorderSize = 0;
            this.Group_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Group_Button.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Group_Button.ForeColor = System.Drawing.Color.White;
            this.Group_Button.Location = new System.Drawing.Point(23, 150);
            this.Group_Button.Name = "Group_Button";
            this.Group_Button.Size = new System.Drawing.Size(120, 36);
            this.Group_Button.TabIndex = 5;
            this.Group_Button.Text = "Grupės";
            this.Group_Button.UseVisualStyleBackColor = false;
            this.Group_Button.Click += new System.EventHandler(this.Group_Button_Click);
            // 
            // Subject_Button
            // 
            this.Subject_Button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Subject_Button.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Subject_Button.FlatAppearance.BorderSize = 0;
            this.Subject_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Subject_Button.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Subject_Button.ForeColor = System.Drawing.Color.White;
            this.Subject_Button.Location = new System.Drawing.Point(23, 108);
            this.Subject_Button.Name = "Subject_Button";
            this.Subject_Button.Size = new System.Drawing.Size(120, 36);
            this.Subject_Button.TabIndex = 4;
            this.Subject_Button.Text = "Dalykai";
            this.Subject_Button.UseVisualStyleBackColor = false;
            this.Subject_Button.Click += new System.EventHandler(this.Subject_Button_Click);
            // 
            // StudentPanelButton
            // 
            this.StudentPanelButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentPanelButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentPanelButton.FlatAppearance.BorderSize = 0;
            this.StudentPanelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StudentPanelButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.StudentPanelButton.ForeColor = System.Drawing.Color.White;
            this.StudentPanelButton.Location = new System.Drawing.Point(23, 66);
            this.StudentPanelButton.Name = "StudentPanelButton";
            this.StudentPanelButton.Size = new System.Drawing.Size(120, 36);
            this.StudentPanelButton.TabIndex = 3;
            this.StudentPanelButton.Text = "Studentai";
            this.StudentPanelButton.UseVisualStyleBackColor = false;
            this.StudentPanelButton.Click += new System.EventHandler(this.StudentPanelButton_Click);
            // 
            // TeacherPanelButton
            // 
            this.TeacherPanelButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TeacherPanelButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TeacherPanelButton.FlatAppearance.BorderSize = 0;
            this.TeacherPanelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TeacherPanelButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TeacherPanelButton.ForeColor = System.Drawing.Color.White;
            this.TeacherPanelButton.Location = new System.Drawing.Point(23, 21);
            this.TeacherPanelButton.Name = "TeacherPanelButton";
            this.TeacherPanelButton.Size = new System.Drawing.Size(120, 36);
            this.TeacherPanelButton.TabIndex = 2;
            this.TeacherPanelButton.Text = "Dėstytojai";
            this.TeacherPanelButton.UseVisualStyleBackColor = false;
            this.TeacherPanelButton.Click += new System.EventHandler(this.TeacherPanelButton_Click);
            // 
            // TeachersPanel
            // 
            this.TeachersPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TeachersPanel.Controls.Add(this.AddTeacherButton);
            this.TeachersPanel.Controls.Add(this.TeacherGrid);
            this.TeachersPanel.Controls.Add(this.panel3);
            this.TeachersPanel.Location = new System.Drawing.Point(188, 64);
            this.TeachersPanel.Name = "TeachersPanel";
            this.TeachersPanel.Size = new System.Drawing.Size(1003, 224);
            this.TeachersPanel.TabIndex = 2;
            // 
            // AddTeacherButton
            // 
            this.AddTeacherButton.FlatAppearance.BorderSize = 0;
            this.AddTeacherButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddTeacherButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddTeacherButton.ForeColor = System.Drawing.Color.RoyalBlue;
            this.AddTeacherButton.Location = new System.Drawing.Point(8, 119);
            this.AddTeacherButton.Name = "AddTeacherButton";
            this.AddTeacherButton.Size = new System.Drawing.Size(130, 33);
            this.AddTeacherButton.TabIndex = 2;
            this.AddTeacherButton.Text = "Pridėti dėstytoją";
            this.AddTeacherButton.UseVisualStyleBackColor = true;
            this.AddTeacherButton.Click += new System.EventHandler(this.AddTeacherButton_Click);
            // 
            // TeacherGrid
            // 
            this.TeacherGrid.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TeacherGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.TeacherGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TeacherGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.TeacherGrid.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.TeacherGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TeacherGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TeacherGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.GlobalUserID,
            this.Teacher_ID,
            this.UserName,
            this.UserSurname,
            this.EmailAddress,
            this.PhoneNumber,
            this.FullAddress,
            this.dataGridViewButtonColumn1,
            this.dataGridViewButtonColumn2});
            this.TeacherGrid.Location = new System.Drawing.Point(4, 158);
            this.TeacherGrid.Name = "TeacherGrid";
            this.TeacherGrid.RowHeadersVisible = false;
            this.TeacherGrid.RowHeadersWidth = 50;
            this.TeacherGrid.RowTemplate.Height = 25;
            this.TeacherGrid.Size = new System.Drawing.Size(990, 66);
            this.TeacherGrid.TabIndex = 3;
            this.TeacherGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TeacherGrid_CellClick);
            // 
            // GlobalUserID
            // 
            this.GlobalUserID.DataPropertyName = "User_ID";
            this.GlobalUserID.HeaderText = "Global_User_ID";
            this.GlobalUserID.Name = "GlobalUserID";
            this.GlobalUserID.Visible = false;
            // 
            // Teacher_ID
            // 
            this.Teacher_ID.DataPropertyName = "Teacher_ID";
            this.Teacher_ID.HeaderText = "ID";
            this.Teacher_ID.Name = "Teacher_ID";
            // 
            // UserName
            // 
            this.UserName.DataPropertyName = "Name";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.UserName.DefaultCellStyle = dataGridViewCellStyle2;
            this.UserName.HeaderText = "Vardas";
            this.UserName.Name = "UserName";
            // 
            // UserSurname
            // 
            this.UserSurname.DataPropertyName = "Surname";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.UserSurname.DefaultCellStyle = dataGridViewCellStyle3;
            this.UserSurname.HeaderText = "Pavardė";
            this.UserSurname.Name = "UserSurname";
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "Email";
            this.EmailAddress.HeaderText = "El. paštas";
            this.EmailAddress.Name = "EmailAddress";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.DataPropertyName = "Phone";
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PhoneNumber.DefaultCellStyle = dataGridViewCellStyle4;
            this.PhoneNumber.HeaderText = "Telefono Nr.";
            this.PhoneNumber.Name = "PhoneNumber";
            // 
            // FullAddress
            // 
            this.FullAddress.DataPropertyName = "Address";
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.FullAddress.DefaultCellStyle = dataGridViewCellStyle5;
            this.FullAddress.HeaderText = "Adresas";
            this.FullAddress.Name = "FullAddress";
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn1.HeaderText = "Ištrinti";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.Text = "Ištrinti";
            this.dataGridViewButtonColumn1.UseColumnTextForButtonValue = true;
            // 
            // dataGridViewButtonColumn2
            // 
            this.dataGridViewButtonColumn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn2.HeaderText = "Redaguoti";
            this.dataGridViewButtonColumn2.Name = "dataGridViewButtonColumn2";
            this.dataGridViewButtonColumn2.Text = "Redaguoti";
            this.dataGridViewButtonColumn2.UseColumnTextForButtonValue = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Location = new System.Drawing.Point(8, 21);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(995, 78);
            this.panel3.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox2.ForeColor = System.Drawing.Color.White;
            this.textBox2.Location = new System.Drawing.Point(19, 17);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(168, 47);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "Dėstytojai";
            // 
            // Global_User_ID
            // 
            this.Global_User_ID.DataPropertyName = "User_ID";
            this.Global_User_ID.HeaderText = "Global_User_ID";
            this.Global_User_ID.Name = "Global_User_ID";
            this.Global_User_ID.Visible = false;
            // 
            // User_ID
            // 
            this.User_ID.DataPropertyName = "Teacher_ID";
            this.User_ID.HeaderText = "ID";
            this.User_ID.Name = "User_ID";
            // 
            // User_Name
            // 
            this.User_Name.DataPropertyName = "Name";
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.User_Name.DefaultCellStyle = dataGridViewCellStyle6;
            this.User_Name.HeaderText = "Vardas";
            this.User_Name.Name = "User_Name";
            // 
            // Surname
            // 
            this.Surname.DataPropertyName = "Surname";
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Surname.DefaultCellStyle = dataGridViewCellStyle7;
            this.Surname.HeaderText = "Pavardė";
            this.Surname.Name = "Surname";
            // 
            // Email
            // 
            this.Email.DataPropertyName = "Email";
            this.Email.HeaderText = "El. paštas";
            this.Email.Name = "Email";
            // 
            // Phone
            // 
            this.Phone.DataPropertyName = "Phone";
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Phone.DefaultCellStyle = dataGridViewCellStyle8;
            this.Phone.HeaderText = "Telefono Nr.";
            this.Phone.Name = "Phone";
            // 
            // Address
            // 
            this.Address.DataPropertyName = "Address";
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Address.DefaultCellStyle = dataGridViewCellStyle9;
            this.Address.HeaderText = "Adresas";
            this.Address.Name = "Address";
            // 
            // Year
            // 
            this.Year.DataPropertyName = "Start_Year";
            this.Year.HeaderText = "Regitravimo metai";
            this.Year.Name = "Year";
            // 
            // TeacherDeleteButton
            // 
            this.TeacherDeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TeacherDeleteButton.HeaderText = "Ištrinti";
            this.TeacherDeleteButton.Name = "TeacherDeleteButton";
            this.TeacherDeleteButton.Text = "Ištrinti";
            this.TeacherDeleteButton.UseColumnTextForButtonValue = true;
            // 
            // Column6
            // 
            this.Column6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column6.HeaderText = "Redaguoti";
            this.Column6.Name = "Column6";
            this.Column6.Text = "Redaguoti";
            this.Column6.UseColumnTextForButtonValue = true;
            // 
            // StudentPanel
            // 
            this.StudentPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.StudentPanel.Controls.Add(this.StudentGrid);
            this.StudentPanel.Controls.Add(this.AddStudentButton);
            this.StudentPanel.Controls.Add(this.panel5);
            this.StudentPanel.Location = new System.Drawing.Point(188, 294);
            this.StudentPanel.Name = "StudentPanel";
            this.StudentPanel.Size = new System.Drawing.Size(1003, 245);
            this.StudentPanel.TabIndex = 3;
            // 
            // StudentGrid
            // 
            this.StudentGrid.AllowUserToAddRows = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.StudentGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.StudentGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.StudentGrid.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.StudentGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.StudentGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StudentGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Student_ID,
            this.UserID,
            this.Student_Name,
            this.StudentSurnameData,
            this.Gmail,
            this.StudentPhoneNumber,
            this.StudentAddress,
            this.Start_Year,
            this.dataGridViewButtonColumn3,
            this.dataGridViewButtonColumn4});
            this.StudentGrid.Location = new System.Drawing.Point(3, 158);
            this.StudentGrid.Name = "StudentGrid";
            this.StudentGrid.RowHeadersVisible = false;
            this.StudentGrid.RowHeadersWidth = 50;
            this.StudentGrid.RowTemplate.Height = 25;
            this.StudentGrid.Size = new System.Drawing.Size(991, 84);
            this.StudentGrid.TabIndex = 4;
            this.StudentGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StudentGrid_CellClick);
            // 
            // Student_ID
            // 
            this.Student_ID.DataPropertyName = "Student_ID";
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Student_ID.DefaultCellStyle = dataGridViewCellStyle11;
            this.Student_ID.HeaderText = "ID";
            this.Student_ID.Name = "Student_ID";
            // 
            // UserID
            // 
            this.UserID.DataPropertyName = "User_ID";
            this.UserID.HeaderText = "Global_User_ID";
            this.UserID.Name = "UserID";
            this.UserID.Visible = false;
            // 
            // Student_Name
            // 
            this.Student_Name.DataPropertyName = "Name";
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Student_Name.DefaultCellStyle = dataGridViewCellStyle12;
            this.Student_Name.HeaderText = "Vardas";
            this.Student_Name.Name = "Student_Name";
            // 
            // StudentSurnameData
            // 
            this.StudentSurnameData.DataPropertyName = "Surname";
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentSurnameData.DefaultCellStyle = dataGridViewCellStyle13;
            this.StudentSurnameData.HeaderText = "Pavardė";
            this.StudentSurnameData.Name = "StudentSurnameData";
            // 
            // Gmail
            // 
            this.Gmail.DataPropertyName = "Email";
            this.Gmail.HeaderText = "El. paštas";
            this.Gmail.Name = "Gmail";
            // 
            // StudentPhoneNumber
            // 
            this.StudentPhoneNumber.DataPropertyName = "Phone";
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentPhoneNumber.DefaultCellStyle = dataGridViewCellStyle14;
            this.StudentPhoneNumber.HeaderText = "Telefono Nr.";
            this.StudentPhoneNumber.Name = "StudentPhoneNumber";
            // 
            // StudentAddress
            // 
            this.StudentAddress.DataPropertyName = "Address";
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentAddress.DefaultCellStyle = dataGridViewCellStyle15;
            this.StudentAddress.HeaderText = "Adresas";
            this.StudentAddress.Name = "StudentAddress";
            // 
            // Start_Year
            // 
            this.Start_Year.DataPropertyName = "Start_Year";
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Start_Year.DefaultCellStyle = dataGridViewCellStyle16;
            this.Start_Year.HeaderText = "Įregistravimo metai";
            this.Start_Year.Name = "Start_Year";
            // 
            // dataGridViewButtonColumn3
            // 
            this.dataGridViewButtonColumn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn3.HeaderText = "Ištrinti";
            this.dataGridViewButtonColumn3.Name = "dataGridViewButtonColumn3";
            this.dataGridViewButtonColumn3.Text = "Ištrinti";
            this.dataGridViewButtonColumn3.UseColumnTextForButtonValue = true;
            // 
            // dataGridViewButtonColumn4
            // 
            this.dataGridViewButtonColumn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn4.HeaderText = "Redaguoti";
            this.dataGridViewButtonColumn4.Name = "dataGridViewButtonColumn4";
            this.dataGridViewButtonColumn4.Text = "Redaguoti";
            this.dataGridViewButtonColumn4.UseColumnTextForButtonValue = true;
            // 
            // AddStudentButton
            // 
            this.AddStudentButton.FlatAppearance.BorderSize = 0;
            this.AddStudentButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddStudentButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddStudentButton.ForeColor = System.Drawing.Color.RoyalBlue;
            this.AddStudentButton.Location = new System.Drawing.Point(8, 119);
            this.AddStudentButton.Name = "AddStudentButton";
            this.AddStudentButton.Size = new System.Drawing.Size(130, 33);
            this.AddStudentButton.TabIndex = 2;
            this.AddStudentButton.Text = "Pridėti studentą";
            this.AddStudentButton.UseVisualStyleBackColor = true;
            this.AddStudentButton.Click += new System.EventHandler(this.AddStudentButton_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel5.Controls.Add(this.textBox1);
            this.panel5.Location = new System.Drawing.Point(8, 21);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(995, 78);
            this.panel5.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(19, 17);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(168, 47);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Studentai";
            // 
            // StudentID
            // 
            this.StudentID.DataPropertyName = "Student_ID";
            this.StudentID.HeaderText = "ID";
            this.StudentID.Name = "StudentID";
            // 
            // Student_User_ID
            // 
            this.Student_User_ID.DataPropertyName = "User_ID";
            this.Student_User_ID.HeaderText = "Global_User_ID";
            this.Student_User_ID.Name = "Student_User_ID";
            this.Student_User_ID.Visible = false;
            // 
            // SurnameName
            // 
            this.SurnameName.DataPropertyName = "Name";
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SurnameName.DefaultCellStyle = dataGridViewCellStyle17;
            this.SurnameName.HeaderText = "Vardas";
            this.SurnameName.Name = "SurnameName";
            // 
            // StudentSurname
            // 
            this.StudentSurname.DataPropertyName = "Surname";
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentSurname.DefaultCellStyle = dataGridViewCellStyle18;
            this.StudentSurname.HeaderText = "Pavardė";
            this.StudentSurname.Name = "StudentSurname";
            // 
            // StudentEmail
            // 
            this.StudentEmail.DataPropertyName = "Email";
            this.StudentEmail.HeaderText = "El. paštas";
            this.StudentEmail.Name = "StudentEmail";
            // 
            // StudentPhone
            // 
            this.StudentPhone.DataPropertyName = "Phone";
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentPhone.DefaultCellStyle = dataGridViewCellStyle19;
            this.StudentPhone.HeaderText = "Telefono Nr.";
            this.StudentPhone.Name = "StudentPhone";
            // 
            // StudentName
            // 
            this.StudentName.DataPropertyName = "Address";
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentName.DefaultCellStyle = dataGridViewCellStyle20;
            this.StudentName.HeaderText = "Adresas";
            this.StudentName.Name = "StudentName";
            // 
            // StudentYear
            // 
            this.StudentYear.DataPropertyName = "Start_Year";
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StudentYear.DefaultCellStyle = dataGridViewCellStyle21;
            this.StudentYear.HeaderText = "Įstojimo metai";
            this.StudentYear.Name = "StudentYear";
            // 
            // Ištrinti
            // 
            this.Ištrinti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ištrinti.HeaderText = "Ištrinti";
            this.Ištrinti.Name = "Ištrinti";
            this.Ištrinti.Text = "Ištrinti";
            this.Ištrinti.UseColumnTextForButtonValue = true;
            // 
            // Redaguoti
            // 
            this.Redaguoti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Redaguoti.HeaderText = "Redaguoti";
            this.Redaguoti.Name = "Redaguoti";
            this.Redaguoti.Text = "Redaguoti";
            this.Redaguoti.UseColumnTextForButtonValue = true;
            // 
            // SubjectPanel
            // 
            this.SubjectPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.SubjectPanel.Controls.Add(this.AddGroup);
            this.SubjectPanel.Controls.Add(this.SubjectGrid);
            this.SubjectPanel.Controls.Add(this.panel6);
            this.SubjectPanel.Location = new System.Drawing.Point(188, 545);
            this.SubjectPanel.Name = "SubjectPanel";
            this.SubjectPanel.Size = new System.Drawing.Size(995, 228);
            this.SubjectPanel.TabIndex = 4;
            // 
            // AddGroup
            // 
            this.AddGroup.FlatAppearance.BorderSize = 0;
            this.AddGroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddGroup.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddGroup.ForeColor = System.Drawing.Color.RoyalBlue;
            this.AddGroup.Location = new System.Drawing.Point(8, 117);
            this.AddGroup.Name = "AddGroup";
            this.AddGroup.Size = new System.Drawing.Size(130, 33);
            this.AddGroup.TabIndex = 5;
            this.AddGroup.Text = "Pridėti dalyką";
            this.AddGroup.UseVisualStyleBackColor = true;
            this.AddGroup.Click += new System.EventHandler(this.AddGroup_Click);
            // 
            // SubjectGrid
            // 
            this.SubjectGrid.AllowUserToAddRows = false;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SubjectGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle22;
            this.SubjectGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SubjectGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.SubjectGrid.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.SubjectGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SubjectGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SubjectGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Subject_Teacher_ID,
            this.Subject_Type_ID,
            this.Subject_ID,
            this.Subject_Name,
            this.Teacher_Name,
            this.Teacher_Surname,
            this.Unique_Name,
            this.dataGridViewButtonColumn5,
            this.dataGridViewButtonColumn6});
            this.SubjectGrid.Location = new System.Drawing.Point(3, 156);
            this.SubjectGrid.Name = "SubjectGrid";
            this.SubjectGrid.RowHeadersVisible = false;
            this.SubjectGrid.RowHeadersWidth = 50;
            this.SubjectGrid.RowTemplate.Height = 25;
            this.SubjectGrid.Size = new System.Drawing.Size(991, 72);
            this.SubjectGrid.TabIndex = 5;
            this.SubjectGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SubjectGrid_CellClick);
            // 
            // Subject_Teacher_ID
            // 
            this.Subject_Teacher_ID.DataPropertyName = "Teacher_ID";
            this.Subject_Teacher_ID.HeaderText = "Dėstytojo_ID";
            this.Subject_Teacher_ID.Name = "Subject_Teacher_ID";
            this.Subject_Teacher_ID.Visible = false;
            // 
            // Subject_Type_ID
            // 
            this.Subject_Type_ID.DataPropertyName = "Subject_Type_ID";
            this.Subject_Type_ID.HeaderText = "Tipas";
            this.Subject_Type_ID.Name = "Subject_Type_ID";
            this.Subject_Type_ID.Visible = false;
            // 
            // Subject_ID
            // 
            this.Subject_ID.DataPropertyName = "Subject_ID";
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Subject_ID.DefaultCellStyle = dataGridViewCellStyle23;
            this.Subject_ID.HeaderText = "Dalyko ID";
            this.Subject_ID.Name = "Subject_ID";
            // 
            // Subject_Name
            // 
            this.Subject_Name.DataPropertyName = "subjectName";
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Subject_Name.DefaultCellStyle = dataGridViewCellStyle24;
            this.Subject_Name.HeaderText = "Dalyko pavadinimas";
            this.Subject_Name.Name = "Subject_Name";
            // 
            // Teacher_Name
            // 
            this.Teacher_Name.DataPropertyName = "Name";
            this.Teacher_Name.HeaderText = "Dėstytojo vardas";
            this.Teacher_Name.Name = "Teacher_Name";
            // 
            // Teacher_Surname
            // 
            this.Teacher_Surname.DataPropertyName = "Surname";
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Teacher_Surname.DefaultCellStyle = dataGridViewCellStyle25;
            this.Teacher_Surname.HeaderText = "Dėstytojo pavardė";
            this.Teacher_Surname.Name = "Teacher_Surname";
            // 
            // Unique_Name
            // 
            this.Unique_Name.DataPropertyName = "Unique_Subject_Name";
            this.Unique_Name.HeaderText = "Unikalus dalyko pavadinimas";
            this.Unique_Name.Name = "Unique_Name";
            // 
            // dataGridViewButtonColumn5
            // 
            this.dataGridViewButtonColumn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn5.HeaderText = "Ištrinti";
            this.dataGridViewButtonColumn5.Name = "dataGridViewButtonColumn5";
            this.dataGridViewButtonColumn5.Text = "Ištrinti";
            this.dataGridViewButtonColumn5.UseColumnTextForButtonValue = true;
            // 
            // dataGridViewButtonColumn6
            // 
            this.dataGridViewButtonColumn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn6.HeaderText = "Redaguoti";
            this.dataGridViewButtonColumn6.Name = "dataGridViewButtonColumn6";
            this.dataGridViewButtonColumn6.Text = "Redaguoti";
            this.dataGridViewButtonColumn6.UseColumnTextForButtonValue = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel6.Controls.Add(this.textBox3);
            this.panel6.Location = new System.Drawing.Point(8, 23);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(987, 78);
            this.panel6.TabIndex = 0;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(19, 17);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(168, 47);
            this.textBox3.TabIndex = 5;
            this.textBox3.Text = "Dalykai";
            // 
            // GroupsPanel
            // 
            this.GroupsPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.GroupsPanel.Controls.Add(this.AddGroup_Button);
            this.GroupsPanel.Controls.Add(this.GroupGrid);
            this.GroupsPanel.Controls.Add(this.panel7);
            this.GroupsPanel.Location = new System.Drawing.Point(188, 779);
            this.GroupsPanel.Name = "GroupsPanel";
            this.GroupsPanel.Size = new System.Drawing.Size(994, 283);
            this.GroupsPanel.TabIndex = 5;
            // 
            // AddGroup_Button
            // 
            this.AddGroup_Button.FlatAppearance.BorderSize = 0;
            this.AddGroup_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddGroup_Button.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddGroup_Button.ForeColor = System.Drawing.Color.RoyalBlue;
            this.AddGroup_Button.Location = new System.Drawing.Point(8, 116);
            this.AddGroup_Button.Name = "AddGroup_Button";
            this.AddGroup_Button.Size = new System.Drawing.Size(211, 33);
            this.AddGroup_Button.TabIndex = 6;
            this.AddGroup_Button.Text = "Pridėti studentą prie grupės";
            this.AddGroup_Button.UseVisualStyleBackColor = true;
            this.AddGroup_Button.Click += new System.EventHandler(this.AddGroup_Button_Click);
            // 
            // GroupGrid
            // 
            this.GroupGrid.AllowUserToAddRows = false;
            this.GroupGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GroupGrid.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.GroupGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GroupGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.GroupGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GroupGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Group_ID,
            this.dataGridViewTextBoxColumn1,
            this.Student_Surname,
            this.Group_Subject_Name,
            this.Group_Name,
            this.Starting_Year,
            this.Delete_Group,
            this.Edit_Group});
            this.GroupGrid.Location = new System.Drawing.Point(8, 158);
            this.GroupGrid.Name = "GroupGrid";
            this.GroupGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.GroupGrid.RowHeadersVisible = false;
            this.GroupGrid.RowTemplate.Height = 25;
            this.GroupGrid.Size = new System.Drawing.Size(986, 125);
            this.GroupGrid.TabIndex = 2;
            this.GroupGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GroupGrid_CellClick);
            // 
            // Group_ID
            // 
            this.Group_ID.DataPropertyName = "Subject_Group_ID";
            this.Group_ID.HeaderText = "Grupės ID";
            this.Group_ID.Name = "Group_ID";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn1.HeaderText = "Studento vardas";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // Student_Surname
            // 
            this.Student_Surname.DataPropertyName = "Surname";
            this.Student_Surname.HeaderText = "Studento pavardė";
            this.Student_Surname.Name = "Student_Surname";
            // 
            // Group_Subject_Name
            // 
            this.Group_Subject_Name.DataPropertyName = "Subject_Name";
            this.Group_Subject_Name.HeaderText = "Dalyko pavadinimas";
            this.Group_Subject_Name.Name = "Group_Subject_Name";
            // 
            // Group_Name
            // 
            this.Group_Name.DataPropertyName = "Unique_Subject_Name";
            this.Group_Name.HeaderText = "Grupės pavadinimas";
            this.Group_Name.Name = "Group_Name";
            // 
            // Starting_Year
            // 
            this.Starting_Year.DataPropertyName = "Year";
            this.Starting_Year.HeaderText = "Įregistravimo metai";
            this.Starting_Year.Name = "Starting_Year";
            // 
            // Delete_Group
            // 
            this.Delete_Group.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete_Group.HeaderText = "Ištrinti";
            this.Delete_Group.Name = "Delete_Group";
            this.Delete_Group.Text = "Ištrinti";
            this.Delete_Group.UseColumnTextForButtonValue = true;
            // 
            // Edit_Group
            // 
            this.Edit_Group.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Edit_Group.HeaderText = "Redaguoti";
            this.Edit_Group.Name = "Edit_Group";
            this.Edit_Group.Text = "Redaguoti";
            this.Edit_Group.UseColumnTextForButtonValue = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel7.Controls.Add(this.textBox4);
            this.panel7.Location = new System.Drawing.Point(8, 25);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(987, 78);
            this.panel7.TabIndex = 1;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Location = new System.Drawing.Point(19, 17);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(168, 47);
            this.textBox4.TabIndex = 5;
            this.textBox4.Text = "Grupės";
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 1061);
            this.Controls.Add(this.GroupsPanel);
            this.Controls.Add(this.SubjectPanel);
            this.Controls.Add(this.StudentPanel);
            this.Controls.Add(this.TeachersPanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "AdminPanel";
            this.Text = "Administratoriaus langas";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.TeachersPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TeacherGrid)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.StudentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.StudentGrid)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.SubjectPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SubjectGrid)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.GroupsPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GroupGrid)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button TeacherPanelButton;
        private System.Windows.Forms.Panel TeachersPanel;
        private System.Windows.Forms.Button AddTeacherButton;
        private System.Windows.Forms.DataGridView teacherGrid;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button StudentPanelButton;
        private System.Windows.Forms.Panel StudentPanel;
        private System.Windows.Forms.Button AddStudentButton;
        private System.Windows.Forms.DataGridView StudentGrid;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_User_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SurnameName;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentSurname;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentPhone;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentName;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentYear;
        private System.Windows.Forms.DataGridViewButtonColumn Ištrinti;
        private System.Windows.Forms.DataGridViewButtonColumn Redaguoti;
        private System.Windows.Forms.DataGridViewTextBoxColumn Global_User_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn User_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn User_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Surname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Year;
        private System.Windows.Forms.DataGridViewButtonColumn TeacherDeleteButton;
        private System.Windows.Forms.DataGridViewButtonColumn Column6;
        private System.Windows.Forms.DataGridView TeacherGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn GlobalUserID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Teacher_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserSurname;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn FullAddress;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentSurnameData;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentPhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn Start_Year;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn3;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn4;
        private System.Windows.Forms.Button Subject_Button;
        private System.Windows.Forms.Panel SubjectPanel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.DataGridView SubjectGrid;
        private System.Windows.Forms.Button AddGroup;
        private System.Windows.Forms.Button Group_Button;
        private System.Windows.Forms.Panel GroupsPanel;
        private System.Windows.Forms.Button AddGroup_Button;
        private System.Windows.Forms.DataGridView GroupGrid;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_Surname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group_Subject_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Starting_Year;
        private System.Windows.Forms.DataGridViewButtonColumn Delete_Group;
        private System.Windows.Forms.DataGridViewButtonColumn Edit_Group;
        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject_Teacher_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject_Type_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Teacher_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Teacher_Surname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unique_Name;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn5;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn6;
    }
}