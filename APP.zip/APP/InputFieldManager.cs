﻿
namespace APP
{
    class InputFieldManager
    {
        public static bool CheckForEmptyInputFields(string[] stringArray)
        {
            for (int i = 0; i < stringArray.Length; i++)
            {
                if (stringArray[i].Equals(""))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
