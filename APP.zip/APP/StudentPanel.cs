﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class StudentPanel : Form
    {
        private int userID, selectedItemID;
        private Login loginPrompt;
        private Database db = new Database();

        public StudentPanel(Login _loginPrompt, int _userID)
        {
            InitializeComponent();
            loginPrompt = _loginPrompt;
            userID = _userID;

            PopulateSubjectList();
        }

        private void UpdateGrid(string command)
        {
            DataTable table = new DataTable();

            MySqlConnection connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            MySqlDataAdapter adapter = new MySqlDataAdapter(command, connection);
            adapter.Fill(table);

            StudentGrid.DataSource = table;

            db.CloseConnectionToDatabase();

            StudentGrid.ClearSelection();
        }

        private void PopulateSubjectList()
        {
            MySqlCommand userCommand;
            MySqlConnection connection;
            MySqlDataReader dataReader;

            connection = db.GetConnectionToDatabase();

            db.OpenConnectionToDatabase();


            string query = "select subject_group.Subject_ID, subject_group.Subject_Group_ID, subject.Subject_Name, subject.Unique_Subject_Name from subject_group inner join subject on subject.Subject_ID = subject_group.Subject_ID where subject_group.User_ID = @userID";
            userCommand = new MySqlCommand(query, connection);
            userCommand.Parameters.AddWithValue("@userID", userID);

            try
            {
                dataReader = userCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    SubjectList.Items.Add(dataReader.GetString(0) + " " + dataReader.GetString(1) + " " + dataReader.GetString(2) + " (" + dataReader.GetString(3) + ")");
                }

                dataReader.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
            }
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginPrompt.Show();
        }

        private void SubjectList_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedItemID = Convert.ToInt32(SubjectList.Text.Split(' ', '.')[0]);

            string mainCommand = "select subject.Subject_Name, subject.Unique_Subject_Name, grades.Grade, grades.Comment, grades.Date from grades inner join subject on subject.Subject_ID = " + selectedItemID;
            UpdateGrid(mainCommand);
        }
    }
}
