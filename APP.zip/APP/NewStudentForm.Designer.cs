﻿
namespace APP
{
    partial class NewStudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddStudentPanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.PhoneText = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.AddressText = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.SurnameText = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.NameText = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.StudentEmailText = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.StartingYearText = new System.Windows.Forms.TextBox();
            this.AddStudentPanel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddStudentPanel
            // 
            this.AddStudentPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.AddStudentPanel.Controls.Add(this.textBox2);
            this.AddStudentPanel.Controls.Add(this.StartingYearText);
            this.AddStudentPanel.Controls.Add(this.textBox1);
            this.AddStudentPanel.Controls.Add(this.StudentEmailText);
            this.AddStudentPanel.Controls.Add(this.button1);
            this.AddStudentPanel.Controls.Add(this.textBox11);
            this.AddStudentPanel.Controls.Add(this.PhoneText);
            this.AddStudentPanel.Controls.Add(this.textBox9);
            this.AddStudentPanel.Controls.Add(this.AddressText);
            this.AddStudentPanel.Controls.Add(this.textBox7);
            this.AddStudentPanel.Controls.Add(this.SurnameText);
            this.AddStudentPanel.Controls.Add(this.textBox6);
            this.AddStudentPanel.Controls.Add(this.NameText);
            this.AddStudentPanel.Controls.Add(this.panel5);
            this.AddStudentPanel.Location = new System.Drawing.Point(0, -4);
            this.AddStudentPanel.Name = "AddStudentPanel";
            this.AddStudentPanel.Size = new System.Drawing.Size(290, 527);
            this.AddStudentPanel.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(46, 467);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(185, 47);
            this.button1.TabIndex = 13;
            this.button1.Text = "Pridėti Studentą";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Location = new System.Drawing.Point(23, 267);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 16);
            this.textBox11.TabIndex = 11;
            this.textBox11.Text = "Telefono Nr.:";
            // 
            // PhoneText
            // 
            this.PhoneText.Location = new System.Drawing.Point(23, 286);
            this.PhoneText.Multiline = true;
            this.PhoneText.Name = "PhoneText";
            this.PhoneText.Size = new System.Drawing.Size(242, 28);
            this.PhoneText.TabIndex = 10;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Location = new System.Drawing.Point(23, 205);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 16);
            this.textBox9.TabIndex = 9;
            this.textBox9.Text = "Adresas:";
            // 
            // AddressText
            // 
            this.AddressText.Location = new System.Drawing.Point(23, 224);
            this.AddressText.Multiline = true;
            this.AddressText.Name = "AddressText";
            this.AddressText.Size = new System.Drawing.Size(242, 28);
            this.AddressText.TabIndex = 8;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Location = new System.Drawing.Point(23, 144);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 16);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "Pavardė:";
            // 
            // SurnameText
            // 
            this.SurnameText.Location = new System.Drawing.Point(23, 163);
            this.SurnameText.Multiline = true;
            this.SurnameText.Name = "SurnameText";
            this.SurnameText.Size = new System.Drawing.Size(242, 28);
            this.SurnameText.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Location = new System.Drawing.Point(24, 88);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 16);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "Vardas:";
            // 
            // NameText
            // 
            this.NameText.Location = new System.Drawing.Point(24, 107);
            this.NameText.Multiline = true;
            this.NameText.Name = "NameText";
            this.NameText.Size = new System.Drawing.Size(241, 28);
            this.NameText.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.textBox4);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(287, 68);
            this.panel5.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Location = new System.Drawing.Point(3, 16);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(287, 38);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Naujas Studentas";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(23, 330);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 16);
            this.textBox1.TabIndex = 15;
            this.textBox1.Text = "El. pašto adresas:";
            // 
            // StudentEmailText
            // 
            this.StudentEmailText.Location = new System.Drawing.Point(23, 349);
            this.StudentEmailText.Multiline = true;
            this.StudentEmailText.Name = "StudentEmailText";
            this.StudentEmailText.Size = new System.Drawing.Size(242, 28);
            this.StudentEmailText.TabIndex = 14;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(23, 394);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 16);
            this.textBox2.TabIndex = 17;
            this.textBox2.Text = "Įregistravimo metai:";
            // 
            // StartingYearText
            // 
            this.StartingYearText.Location = new System.Drawing.Point(23, 413);
            this.StartingYearText.Multiline = true;
            this.StartingYearText.Name = "StartingYearText";
            this.StartingYearText.Size = new System.Drawing.Size(242, 28);
            this.StartingYearText.TabIndex = 16;
            // 
            // NewStudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 522);
            this.Controls.Add(this.AddStudentPanel);
            this.Name = "NewStudentForm";
            this.Text = "Naujas Studentas";
            this.AddStudentPanel.ResumeLayout(false);
            this.AddStudentPanel.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel AddStudentPanel;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox PhoneText;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox AddressText;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox SurnameText;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox NameText;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox StartingYearText;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox StudentEmailText;
    }
}