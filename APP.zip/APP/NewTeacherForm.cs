﻿using System;
using System.Windows.Forms;

namespace APP
{
    public partial class NewTeacherForm : Form
    {
        private AdminPanel adminPanel;
        private DataGridView dataGrid;

        public NewTeacherForm(AdminPanel _adminPanel, DataGridView _dataGrid)
        {
            InitializeComponent();
            adminPanel = _adminPanel;
            dataGrid = _dataGrid;
        }

        private void AddTeacherButton_Click(object sender, EventArgs e)
        {
            UserAccountManager userManager = new UserAccountManager();
            userManager.AddToDatabase(TeacherNameText, TeacherSurnameText, TeacherAddressText, TeacherPhoneText, TeacherEmailText, null, DataType.Teacher);
            adminPanel.UpdateGrid(dataGrid, "SELECT User_ID, Teacher_ID, Name, Surname, Email, Phone, Address from teachers where User_ID != -1");
            this.Close();
        }
    }
}
