﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class StudentDataEditForm : Form
    {
        int userID;
        string name, surname, email, address, phone, start_year;
        AdminPanel adminPanel;
        DataGridView dataGrid;
        Database db = new Database();

        public StudentDataEditForm(AdminPanel _adminPanel, DataGridView _dataGrid, int _id, string _name, string _surname, string _email, string _address, string _phone, string _start_year)
        {
            InitializeComponent();

            adminPanel = _adminPanel;
            dataGrid = _dataGrid;
            userID = _id;
            name = _name;
            surname = _surname;
            email = _email;
            address = _address;
            phone = _phone;
            start_year = _start_year;

            SetValues();
        }
        
        private void SaveTeacherDataChanges_Button_Click(object sender, EventArgs e)
        {
            string[] inputFields = { StudentNameText.Text, StudentSurnameText.Text, StudentEmailText.Text, StudentPhoneText.Text, StudentAddressText.Text, StudentStartingYear.Text };
            if (InputFieldManager.CheckForEmptyInputFields(inputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            MySqlConnection connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            try
            {
                MySqlCommand command = new MySqlCommand("update students set Name = @name, Surname = @surname, Email = @email, Phone = @phone, Address = @address, Start_Year = @year where User_ID = @id", connection);
                command.Parameters.AddWithValue("@name", StudentNameText.Text);
                command.Parameters.AddWithValue("@surname", StudentSurnameText.Text);
                command.Parameters.AddWithValue("@email", StudentEmailText.Text);
                command.Parameters.AddWithValue("@phone", StudentPhoneText.Text);
                command.Parameters.AddWithValue("@address", StudentAddressText.Text);
                command.Parameters.AddWithValue("@year", Convert.ToInt32(StudentStartingYear.Text));
                command.Parameters.AddWithValue("@id", userID);

                int executionResult = command.ExecuteNonQuery();

                if (executionResult > 0)
                {
                    adminPanel.UpdateGrid(dataGrid, "SELECT Student_ID, User_ID, Name, Surname, Email, Phone, Address, Start_Year from students");

                    MessageBox.Show("Sėkimingai išsaugota");
                }
                else
                {
                    MessageBox.Show("Įvyko klaida");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
                this.Close();
            }
        }

        public void SetValues()
        {
            StudentNameText.Text = name;
            StudentSurnameText.Text = surname;
            StudentEmailText.Text = email;
            StudentAddressText.Text = address;
            StudentPhoneText.Text = phone;
            StudentStartingYear.Text = start_year;
        }
    }
}
