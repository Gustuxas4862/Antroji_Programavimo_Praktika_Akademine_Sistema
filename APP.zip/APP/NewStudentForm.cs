﻿using System;
using System.Windows.Forms;

namespace APP
{
    public partial class NewStudentForm : Form
    {
        private AdminPanel adminPanel;
        private DataGridView dataGrid;

        public NewStudentForm(AdminPanel _adminPanel, DataGridView _dataGrid)
        {
            InitializeComponent();
            adminPanel = _adminPanel;
            dataGrid = _dataGrid;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserAccountManager userManager = new UserAccountManager();
            userManager.AddToDatabase(NameText, SurnameText, AddressText, PhoneText, StudentEmailText, StartingYearText, DataType.Student);
            adminPanel.UpdateGrid(dataGrid, "SELECT Student_ID, User_ID, Name, Surname, Email, Phone, Address, Start_Year from students");
        }
    }
}
