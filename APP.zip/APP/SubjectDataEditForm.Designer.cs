﻿
namespace APP
{
    partial class SubjectDataEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddStudentPanel = new System.Windows.Forms.Panel();
            this.UniqueSubjectName = new System.Windows.Forms.TextBox();
            this.TeacherList = new System.Windows.Forms.ComboBox();
            this.SubjectList = new System.Windows.Forms.ComboBox();
            this.TeacherEmailText = new System.Windows.Forms.TextBox();
            this.SaveSubjectInfoButton = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.AddStudentPanel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddStudentPanel
            // 
            this.AddStudentPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.AddStudentPanel.Controls.Add(this.UniqueSubjectName);
            this.AddStudentPanel.Controls.Add(this.TeacherList);
            this.AddStudentPanel.Controls.Add(this.SubjectList);
            this.AddStudentPanel.Controls.Add(this.TeacherEmailText);
            this.AddStudentPanel.Controls.Add(this.SaveSubjectInfoButton);
            this.AddStudentPanel.Controls.Add(this.textBox7);
            this.AddStudentPanel.Controls.Add(this.textBox6);
            this.AddStudentPanel.Controls.Add(this.panel5);
            this.AddStudentPanel.Location = new System.Drawing.Point(1, -5);
            this.AddStudentPanel.Name = "AddStudentPanel";
            this.AddStudentPanel.Size = new System.Drawing.Size(387, 438);
            this.AddStudentPanel.TabIndex = 8;
            // 
            // UniqueSubjectName
            // 
            this.UniqueSubjectName.Location = new System.Drawing.Point(24, 269);
            this.UniqueSubjectName.Name = "UniqueSubjectName";
            this.UniqueSubjectName.Size = new System.Drawing.Size(339, 23);
            this.UniqueSubjectName.TabIndex = 21;
            // 
            // TeacherList
            // 
            this.TeacherList.FormattingEnabled = true;
            this.TeacherList.Location = new System.Drawing.Point(24, 189);
            this.TeacherList.Name = "TeacherList";
            this.TeacherList.Size = new System.Drawing.Size(339, 23);
            this.TeacherList.TabIndex = 20;
            this.TeacherList.SelectedIndexChanged += new System.EventHandler(this.TeacherList_SelectedIndexChanged);
            // 
            // SubjectList
            // 
            this.SubjectList.FormattingEnabled = true;
            this.SubjectList.Location = new System.Drawing.Point(24, 111);
            this.SubjectList.Name = "SubjectList";
            this.SubjectList.Size = new System.Drawing.Size(339, 23);
            this.SubjectList.TabIndex = 18;
            this.SubjectList.SelectedIndexChanged += new System.EventHandler(this.SubjectList_SelectedIndexChanged);
            // 
            // TeacherEmailText
            // 
            this.TeacherEmailText.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TeacherEmailText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TeacherEmailText.Location = new System.Drawing.Point(24, 167);
            this.TeacherEmailText.Name = "TeacherEmailText";
            this.TeacherEmailText.Size = new System.Drawing.Size(100, 16);
            this.TeacherEmailText.TabIndex = 17;
            this.TeacherEmailText.Text = "Dėstytojas:";
            // 
            // SaveSubjectInfoButton
            // 
            this.SaveSubjectInfoButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SaveSubjectInfoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveSubjectInfoButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SaveSubjectInfoButton.ForeColor = System.Drawing.SystemColors.Control;
            this.SaveSubjectInfoButton.Location = new System.Drawing.Point(106, 366);
            this.SaveSubjectInfoButton.Name = "SaveSubjectInfoButton";
            this.SaveSubjectInfoButton.Size = new System.Drawing.Size(185, 47);
            this.SaveSubjectInfoButton.TabIndex = 13;
            this.SaveSubjectInfoButton.Text = "Išsaugoti Pakeitimus";
            this.SaveSubjectInfoButton.UseVisualStyleBackColor = false;
            this.SaveSubjectInfoButton.Click += new System.EventHandler(this.SaveSubjectInfoButton_Click);
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Location = new System.Drawing.Point(24, 246);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(160, 16);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "Unikalus grupės pavadinimas:";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Location = new System.Drawing.Point(24, 88);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(110, 16);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "Dalyko pavadinimas:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.textBox4);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(387, 68);
            this.panel5.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Location = new System.Drawing.Point(3, 16);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(384, 38);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Atnaujinti Informaciją";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SubjectDataEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 429);
            this.Controls.Add(this.AddStudentPanel);
            this.Name = "SubjectDataEditForm";
            this.Text = "Dalyko redagavimo langas";
            this.AddStudentPanel.ResumeLayout(false);
            this.AddStudentPanel.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel AddStudentPanel;
        private System.Windows.Forms.TextBox TeacherEmailText;
        private System.Windows.Forms.Button SaveSubjectInfoButton;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox TeacherList;
        private System.Windows.Forms.ComboBox SubjectList;
        private System.Windows.Forms.TextBox UniqueSubjectName;
    }
}