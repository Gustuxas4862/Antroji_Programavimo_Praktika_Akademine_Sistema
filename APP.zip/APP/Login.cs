﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace APP
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();

            TextBoxPassword.AutoSize = false;
            TextBoxPassword.Size = new Size(this.TextBoxPassword.Size.Width, 50);

            TextBoxUsername.AutoSize = false;
            TextBoxUsername.Size = new Size(this.TextBoxUsername.Size.Width, 50);
        }

        private void ButtonLogin_Click(object sender, EventArgs e)
        {
            Database newDatabase = new Database();
            DataTable newDataTable = new DataTable();
            MySqlDataAdapter newAdapter = new MySqlDataAdapter();
            MySqlConnection connection = newDatabase.GetConnectionToDatabase();

            newDatabase.OpenConnectionToDatabase();

            string loginCommand = "SELECT * FROM `users` WHERE `Username` = @usrnm and `Password` = @pass";
            MySqlCommand executableCommand = new MySqlCommand(loginCommand, connection);

            string username = TextBoxUsername.Text;
            string password = TextBoxPassword.Text;

            executableCommand.Parameters.Add("@usrnm", MySqlDbType.VarChar).Value = username;
            executableCommand.Parameters.Add("@pass", MySqlDbType.VarChar).Value = password;

            newAdapter.SelectCommand = executableCommand;
            newAdapter.Fill(newDataTable);

            if (newDataTable.Rows.Count > 0)
            {
                MySqlDataReader commandReader = executableCommand.ExecuteReader();
                commandReader.Read();
                string role = commandReader["Role_ID"].ToString();
                string userID = commandReader["Users_ID"].ToString();

                commandReader.Close();


                if (role == "1")
                {
                    this.Hide();
                    AdminPanel adminPanel = new AdminPanel(this);
                    adminPanel.ShowDialog();
                }
                else if (role == "2")
                {
                    this.Hide();

                    MySqlCommand findTeacherID = new MySqlCommand("select Teacher_ID from teachers where User_ID = @id", connection);
                    findTeacherID.Parameters.AddWithValue("@id", userID);

                    commandReader = findTeacherID.ExecuteReader();
                    commandReader.Read();

                    string teacher_ID = commandReader["Teacher_ID"].ToString();
                    commandReader.Close();

                    TeacherPanel teacherPanel = new TeacherPanel(this, Convert.ToInt32(teacher_ID));
                    teacherPanel.ShowDialog();
                }
                else if (role == "3")
                {
                    this.Hide();
                    StudentPanel studentPanel = new StudentPanel(this, Convert.ToInt32(userID));
                    studentPanel.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Įvesti neteisingi prisijungimo duomenys");
            }

            newDatabase.CloseConnectionToDatabase();
        }

        private void TextBoxUsername_Enter(object sender, EventArgs e)
        {
            string usernameHint = TextBoxUsername.Text;
            if (usernameHint.Equals("Vartotojo vardas"))
            {
                TextBoxUsername.Text = "";
            }
        }

        private void TextBoxUsername_Leave(object sender, EventArgs e)
        {
            string usernameHint = TextBoxUsername.Text;
            if (usernameHint.Equals("Vartotojo vardas") || usernameHint.Equals(""))
            {
                TextBoxUsername.Text = "Vartotojo vardas";
                TextBoxUsername.ForeColor = Color.FromName("WindowFrame");
            }
        }

        private void TextBoxPassword_Enter(object sender, EventArgs e)
        {
            string passwordHint = TextBoxPassword.Text;
            if (passwordHint.Equals("Slaptažodis"))
            {
                TextBoxPassword.Text = "";
                TextBoxPassword.UseSystemPasswordChar = true;
            }
        }

        private void TextBoxPassword_Leave(object sender, EventArgs e)
        {
            string passwordHint = TextBoxPassword.Text;
            if (passwordHint.Equals("Slaptažodis") || passwordHint.Equals(""))
            {
                TextBoxPassword.Text = "Slaptažodis";
                TextBoxPassword.UseSystemPasswordChar = false;
                TextBoxPassword.ForeColor = Color.FromName("WindowFrame");
            }
        }
    }
}
