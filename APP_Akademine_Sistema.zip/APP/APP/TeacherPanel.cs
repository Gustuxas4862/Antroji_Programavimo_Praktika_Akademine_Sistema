﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class TeacherPanel : Form
    {
        private int currentTeacherID;
        private Database db = new Database();
        private Login loginPrompt;
        private UserAccountManager dataBaseManager = new UserAccountManager();

        public TeacherPanel(Login _loginPrompt, int _currentTeacherID)
        {
            InitializeComponent();
            loginPrompt = _loginPrompt;

            currentTeacherID = _currentTeacherID;
            string command = "SELECT grades.Grades_ID, grades.Group_ID, grades.Student_ID, grades.Subject_ID, students.Name, students.Surname, grades.Grade, grades.Date, grades.Comment from grades inner join students on students.Student_ID = grades.Student_ID where grades.Student_ID in (select subject_group.Student_ID from subject_group where subject_group.Subject_ID in (select subject.Subject_ID from subject where subject.Teacher_ID = " + currentTeacherID + "))";
            UpdateGrid(GroupGrid, command);
        }

        public void UpdateGrid(DataGridView grid, string command)
        {
            DataTable table = new DataTable();

            MySqlConnection connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            MySqlDataAdapter adapter = new MySqlDataAdapter(command, connection);
            adapter.Fill(table);

            grid.DataSource = table;

            db.CloseConnectionToDatabase();

            grid.ClearSelection();
        }

        private void AddGrade_Click(object sender, EventArgs e)
        {
            AddGradeForm gradeForm = new AddGradeForm(this, GroupGrid, currentTeacherID);
            gradeForm.ShowDialog();
        }

        private void GroupGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string mainCommand = "delete from grades where Grades_ID = @gradeID";
            string updateCommand = "SELECT grades.Grades_ID, grades.Group_ID, grades.Student_ID, grades.Subject_ID, students.Name, students.Surname, grades.Grade, grades.Date, grades.Comment from grades inner join students on students.Student_ID = grades.Student_ID where grades.Student_ID in (select subject_group.Student_ID from subject_group where subject_group.Subject_ID in (select subject.Subject_ID from subject where subject.Teacher_ID = " + currentTeacherID + "))";

            dataBaseManager.TryRemoveFromDatabase(e, GroupGrid, null, this, DataType.Grade, mainCommand, updateCommand);

            dataBaseManager.TryEditTableDatabase(e, GroupGrid, null, this, DataType.Grade, currentTeacherID.ToString());
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginPrompt.Show();
        }
    }
}
