﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class AddGradeForm : Form
    {
        private string query;
        private int currentTeacherID;
        private string[] NewGradeInfo;
        private int[] grades = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        private TeacherPanel teacherPanel;
        private DataGridView grid;
        private Database db = new Database();
        private MySqlCommand userCommand;
        private MySqlConnection connection;
        private MySqlDataReader dataReader;

        public AddGradeForm(TeacherPanel _teacherPanel, DataGridView _grid, int _currentTeacherID)
        {
            InitializeComponent();


            for (int i = 0; i < grades.Length; i++)
            {
                GradeList.Items.Add(grades[i]);
            }

            NewGradeInfo = new string[4];
            teacherPanel = _teacherPanel;
            grid = _grid;
            currentTeacherID = _currentTeacherID;
            PopulateLists();
        }

        private void AddGradeButton_Click(object sender, EventArgs e)
        {
            string[] formInputFields = { DateBox.Text, GradeList.Text, CommentBox.Text };
            if (InputFieldManager.CheckForEmptyInputFields(formInputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            UserAccountManager dataBaseManager = new UserAccountManager();
            dataBaseManager.AddStudentGradeToDatabase(NewGradeInfo[0], NewGradeInfo[1], NewGradeInfo[2], CommentBox.Text, NewGradeInfo[3], DateBox.Text);

            string command = "SELECT grades.Grades_ID, grades.Group_ID, grades.Student_ID, grades.Subject_ID, students.Name, students.Surname, grades.Grade, grades.Date, grades.Comment from grades inner join students on students.Student_ID = grades.Student_ID where grades.Student_ID in (select subject_group.Student_ID from subject_group where subject_group.Subject_ID in (select subject.Subject_ID from subject where subject.Teacher_ID = " + currentTeacherID + "))";
            teacherPanel.UpdateGrid(grid, command);
        }

        private void PopulateLists()
        {
            connection = db.GetConnectionToDatabase();

            db.OpenConnectionToDatabase();

            query = "SELECT subject_group.Subject_Group_ID, subject.Subject_ID, subject.Unique_Subject_Name, subject.Subject_Name from subject inner join subject_group on subject_group.subject_ID = subject.Subject_ID and subject.Teacher_ID = " + currentTeacherID;
            userCommand = new MySqlCommand(query, connection);

            try
            {
                dataReader = userCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    GroupList.Items.Add(dataReader.GetString(0) + " " + dataReader.GetString(1) + " " + dataReader.GetString(2) + " (" + dataReader.GetString(3) + ")");
                }
                dataReader.Close();

            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
            }
        }

        private void GroupList_SelectedIndexChanged(object sender, EventArgs e)
        {
            StudentList.Items.Clear();
            NewGradeInfo = new string[4];
            NewGradeInfo[0] = GroupList.Text.Split(' ')[0];
            NewGradeInfo[3] = GroupList.Text.Split(' ')[1];

            connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            query = "select students.Student_ID, students.Name, students.Surname from students where students.Student_ID in " +
                "(select Student_ID from subject_group where subject_group.Subject_ID in " +
                "(select subject.Subject_ID from subject where subject.Teacher_ID = @id and subject.Subject_ID = @subjectID))";
            userCommand = new MySqlCommand(query, connection);
            userCommand.Parameters.AddWithValue("@id", currentTeacherID);
            userCommand.Parameters.AddWithValue("@subjectID", GroupList.Text.Split(' ')[1]);
            dataReader = userCommand.ExecuteReader();

            while (dataReader.Read())
            {
                StudentList.Items.Add(dataReader.GetString(0) + ". " + dataReader.GetString(1) + " " + dataReader.GetString(2));
            }

            dataReader.Close();
        }

        private void StudentList_SelectedIndexChanged(object sender, EventArgs e)
        {
            NewGradeInfo[1] = StudentList.Text.Split(' ', '.')[0];
        }

        private void GradeList_SelectedIndexChanged(object sender, EventArgs e)
        {
            NewGradeInfo[2] = GradeList.Text;
        }

        private void AddGradeForm_Load_1(object sender, EventArgs e)
        {

        }
    }
}
