﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace APP
{
    public partial class TeacherDataEditForm : Form
    {
        int userID;
        string name, surname, email, address, phone;
        AdminPanel adminPanel;
        DataGridView dataGrid;
        Database db = new Database();

        private void SaveTeacherDataChanges_Button_Click(object sender, EventArgs e)
        {
            string[] inputFields = { TeacherNameText.Text, TeacherSurnameText.Text, TeacherEmailTxt .Text, TeacherPhoneText.Text, TeacherAddressText.Text};
            if (InputFieldManager.CheckForEmptyInputFields(inputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            MySqlConnection connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            try
            {
                MySqlCommand command = new MySqlCommand("update teachers set Name = @name, Surname = @surname, Email = @email, Phone = @phone, Address = @address where Teacher_ID = @id", connection);
                command.Parameters.AddWithValue("@name", TeacherNameText.Text);
                command.Parameters.AddWithValue("@surname", TeacherSurnameText.Text);
                command.Parameters.AddWithValue("@email", TeacherEmailTxt.Text);
                command.Parameters.AddWithValue("@phone", TeacherPhoneText.Text);
                command.Parameters.AddWithValue("@address", TeacherAddressText.Text);
                command.Parameters.AddWithValue("@id", userID);

                int executionResult = command.ExecuteNonQuery();

                if (executionResult > 0)
                {
                    adminPanel.UpdateGrid(dataGrid, "SELECT User_ID, Teacher_ID, Name, Surname, Email, Phone, Address from teachers where User_ID != -1");

                    MessageBox.Show("Sėkimingai išsaugota");
                }
                else
                {
                    MessageBox.Show("Įvyko klaida");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
                this.Close();
            }
        }

        public TeacherDataEditForm(AdminPanel _adminPanel, DataGridView _dataGrid, int _id, string _name, string _surname, string _email, string _address, string _phone)
        {
            InitializeComponent();

            adminPanel = _adminPanel;
            dataGrid = _dataGrid;
            userID = _id;
            name = _name;
            surname = _surname;
            email = _email;
            address = _address;
            phone = _phone;
            SetValues();
        }

        public void SetValues()
        {
            TeacherNameText.Text = name;
            TeacherSurnameText.Text = surname;
            TeacherEmailTxt.Text = email;
            TeacherAddressText.Text = address;
            TeacherPhoneText.Text = phone;
        }
    }
}
