﻿using MySql.Data.MySqlClient;


namespace APP
{
    class Database
    {
        private MySqlConnection connection = new MySqlConnection("server=localhost;port=3306;username=root;password=;database=mydb");

        public void OpenConnectionToDatabase()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public void CloseConnectionToDatabase()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public MySqlConnection GetConnectionToDatabase()
        {
            return connection;
        }
    }
}
