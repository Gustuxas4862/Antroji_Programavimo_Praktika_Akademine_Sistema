﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace APP
{
    public partial class AdminPanel : Form
    {
        private Database db = new Database();
        private Login loginPrompt;
        private List<Panel> adminPanels = new List<Panel>();
        UserAccountManager userManager = new UserAccountManager();

        public AdminPanel(Login _loginPrompt)
        {
            InitializeComponent();
            loginPrompt = _loginPrompt;

            this.Size = new Size(1200, 588);

            InitializePanels();
            AddPanels();
            PanelManager(null);
        }

        private void PanelManager(Panel panel)
        {
            for (int i = 0; i < adminPanels.Count; i++)
            {
                adminPanels[i].Hide();
            }

            if (panel != null)
            {
                panel.Show();
            }
        }

        private void AddPanels()
        {
            adminPanels.Add(TeachersPanel);
            adminPanels.Add(StudentPanel);
            adminPanels.Add(SubjectPanel);
            adminPanels.Add(GroupsPanel);
        }

        private void InitializePanels()
        {
            TeachersPanel.Size = new Size(1003, 499);
            TeachersPanel.Location = new Point(180, 52);
            TeacherGrid.Size = new Size(990, 329);

            StudentPanel.Size = new Size(1003, 499);
            StudentPanel.Location = new Point(180, 52);
            StudentGrid.Size = new Size(990, 329);

            SubjectPanel.Size = new Size(1003, 499);
            SubjectPanel.Location = new Point(180, 52);
            SubjectGrid.Size = new Size(990, 329);

            GroupsPanel.Size = new Size(1003, 499);
            GroupsPanel.Location = new Point(180, 52);
            GroupGrid.Size = new Size(990, 329);
        }

        public void UpdateGrid(DataGridView gridData, string command)
        {
            DataTable table = new DataTable();

            MySqlConnection connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            MySqlDataAdapter adapter = new MySqlDataAdapter(command, connection);
            adapter.Fill(table);

            gridData.DataSource = table;

            db.CloseConnectionToDatabase();

            gridData.ClearSelection();
        }

        private void TeacherPanelButton_Click(object sender, EventArgs e)
        {
            string command = "SELECT User_ID, Teacher_ID, Name, Surname, Email, Phone, Address from teachers where User_ID != -1";
            UpdateGrid(TeacherGrid, command);

            PanelManager(TeachersPanel);
        }

        private void AddTeacherButton_Click(object sender, EventArgs e)
        {
            NewTeacherForm teacherForm = new NewTeacherForm(this, TeacherGrid);
            teacherForm.ShowDialog();
        }

        private void StudentPanelButton_Click(object sender, EventArgs e)
        {
            string command = "SELECT Student_ID, User_ID, Name, Surname, Email, Phone, Address, Start_Year from students";
            UpdateGrid(StudentGrid, command);

            PanelManager(StudentPanel);
        }

        private void TeacherGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string mainCommand = "update subject set Teacher_ID = -1 where Teacher_ID = @teacherID; DELETE FROM teachers where User_ID = @id; DELETE FROM users where Users_ID = @id";
            string updateCommand = "SELECT User_ID, Teacher_ID, Name, Surname, Email, Phone, Address from teachers where User_ID != -1";

            userManager.TryRemoveFromDatabase(e, TeacherGrid, this, null, DataType.Teacher, mainCommand, updateCommand);

            userManager.TryEditTableDatabase(e, TeacherGrid, this, null, DataType.Teacher, null);
        }

        private void StudentGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string mainCommand = "DELETE FROM grades where Student_ID = @studentID; DELETE FROM subject_group where Student_ID = @studentID; DELETE FROM students where User_ID = @id; DELETE FROM users where Users_ID = @id";
            string updateCommand = "SELECT Student_ID, User_ID, Name, Surname, Email, Phone, Address, Start_Year from students";

            userManager.TryRemoveFromDatabase(e, StudentGrid, this, null, DataType.Student, mainCommand, updateCommand);

            userManager.TryEditTableDatabase(e, StudentGrid, this, null, DataType.Student, null);
        }

        private void AddStudentButton_Click(object sender, EventArgs e)
        {
            NewStudentForm studentForm = new NewStudentForm(this, StudentGrid);
            studentForm.ShowDialog();
        }

        private void Subject_Button_Click(object sender, EventArgs e)
        {
            string command = "SELECT subject.Teacher_ID, subject.Subject_Type_ID, subject.Subject_ID, subject_type.Name as subjectName, teachers.Name, teachers.Surname, " +
                "subject.Unique_Subject_Name from subject INNER JOIN teachers on subject.Teacher_ID = teachers.Teacher_ID inner join subject_type on subject.Subject_Type_ID = subject_type.Subject_Type_ID";

            UpdateGrid(SubjectGrid, command);

            PanelManager(SubjectPanel);
        }

        private void AddGroup_Click(object sender, EventArgs e)
        {
            NewSubjectForm subjectForm = new NewSubjectForm(this, SubjectGrid);
            subjectForm.ShowDialog();
        }

        private void Group_Button_Click(object sender, EventArgs e)
        {
            string command = "select subject_group.Subject_Group_ID, students.Name, students.Surname, subject.Subject_Name, subject.Unique_Subject_Name, " +
                "subject_group.Year from subject_group Inner join students on subject_group.Student_ID = students.Student_ID inner join subject on subject.Subject_ID = subject_group.Subject_ID;";
            UpdateGrid(GroupGrid, command);

            PanelManager(GroupsPanel);
        }

        private void AddGroup_Button_Click(object sender, EventArgs e)
        {
            NewGroupForm subjectForm = new NewGroupForm(this, GroupGrid);
            subjectForm.ShowDialog();
        }

        private void SubjectGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string mainCommand = "DELETE from subject where Subject_ID = @subjectID";
            string updateCommand = "SELECT subject.Teacher_ID, subject.Subject_Type_ID, subject.Subject_ID, subject_type.Name as subjectName, teachers.Name, teachers.Surname, " +
                "subject.Unique_Subject_Name from subject INNER JOIN teachers on subject.Teacher_ID = teachers.Teacher_ID inner join subject_type on subject.Subject_Type_ID = subject_type.Subject_Type_ID";

            userManager.TryRemoveFromDatabase(e, SubjectGrid, this, null, DataType.Subject, mainCommand, updateCommand);

            userManager.TryEditTableDatabase(e, SubjectGrid, this, null, DataType.Subject, null);
        }

        private void GroupGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string mainCommand = "DELETE from subject_group where Subject_Group_ID = @groupID";
            string updateCommand = "select subject_group.Subject_Group_ID, students.Name, students.Surname, subject.Subject_Name, subject.Unique_Subject_Name, " +
                "subject_group.Year from subject_group Inner join students on subject_group.Student_ID = students.Student_ID inner join subject on subject.Subject_ID = subject_group.Subject_ID";

            userManager.TryRemoveFromDatabase(e, GroupGrid, this, null, DataType.Group, mainCommand, updateCommand);

            userManager.TryEditTableDatabase(e, GroupGrid, this, null, DataType.Group, null);
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginPrompt.Show();
        }
    }
}
