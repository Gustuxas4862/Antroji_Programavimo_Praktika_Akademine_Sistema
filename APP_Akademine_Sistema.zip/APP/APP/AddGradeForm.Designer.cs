﻿
namespace APP
{
    partial class AddGradeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddStudentPanel = new System.Windows.Forms.Panel();
            this.DateBox = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.StudentList = new System.Windows.Forms.ComboBox();
            this.textbox = new System.Windows.Forms.TextBox();
            this.GroupList = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.CommentBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.GradeList = new System.Windows.Forms.ComboBox();
            this.Save = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.AddStudentPanel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddStudentPanel
            // 
            this.AddStudentPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.AddStudentPanel.Controls.Add(this.DateBox);
            this.AddStudentPanel.Controls.Add(this.textBox5);
            this.AddStudentPanel.Controls.Add(this.StudentList);
            this.AddStudentPanel.Controls.Add(this.textbox);
            this.AddStudentPanel.Controls.Add(this.GroupList);
            this.AddStudentPanel.Controls.Add(this.textBox2);
            this.AddStudentPanel.Controls.Add(this.textBox3);
            this.AddStudentPanel.Controls.Add(this.CommentBox);
            this.AddStudentPanel.Controls.Add(this.textBox1);
            this.AddStudentPanel.Controls.Add(this.GradeList);
            this.AddStudentPanel.Controls.Add(this.Save);
            this.AddStudentPanel.Controls.Add(this.panel5);
            this.AddStudentPanel.Location = new System.Drawing.Point(1, 1);
            this.AddStudentPanel.Name = "AddStudentPanel";
            this.AddStudentPanel.Size = new System.Drawing.Size(372, 626);
            this.AddStudentPanel.TabIndex = 9;
            // 
            // DateBox
            // 
            this.DateBox.Location = new System.Drawing.Point(24, 275);
            this.DateBox.Name = "DateBox";
            this.DateBox.Size = new System.Drawing.Size(330, 23);
            this.DateBox.TabIndex = 32;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Location = new System.Drawing.Point(24, 165);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(160, 16);
            this.textBox5.TabIndex = 31;
            this.textBox5.Text = "Studentas:";
            // 
            // StudentList
            // 
            this.StudentList.FormattingEnabled = true;
            this.StudentList.Location = new System.Drawing.Point(24, 187);
            this.StudentList.Name = "StudentList";
            this.StudentList.Size = new System.Drawing.Size(330, 23);
            this.StudentList.TabIndex = 30;
            this.StudentList.SelectedIndexChanged += new System.EventHandler(this.StudentList_SelectedIndexChanged);
            // 
            // textbox
            // 
            this.textbox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textbox.Location = new System.Drawing.Point(24, 92);
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(160, 16);
            this.textbox.TabIndex = 29;
            this.textbox.Text = "Grupė:";
            // 
            // GroupList
            // 
            this.GroupList.FormattingEnabled = true;
            this.GroupList.Location = new System.Drawing.Point(24, 114);
            this.GroupList.Name = "GroupList";
            this.GroupList.Size = new System.Drawing.Size(330, 23);
            this.GroupList.TabIndex = 28;
            this.GroupList.SelectedIndexChanged += new System.EventHandler(this.GroupList_SelectedIndexChanged);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(24, 252);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(160, 16);
            this.textBox2.TabIndex = 27;
            this.textBox2.Text = "Data:";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(24, 403);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(160, 16);
            this.textBox3.TabIndex = 25;
            this.textBox3.Text = "Komentaras:";
            // 
            // CommentBox
            // 
            this.CommentBox.Location = new System.Drawing.Point(24, 425);
            this.CommentBox.Multiline = true;
            this.CommentBox.Name = "CommentBox";
            this.CommentBox.Size = new System.Drawing.Size(330, 82);
            this.CommentBox.TabIndex = 24;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(24, 334);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(160, 16);
            this.textBox1.TabIndex = 23;
            this.textBox1.Text = "Pažymys:";
            // 
            // GradeList
            // 
            this.GradeList.FormattingEnabled = true;
            this.GradeList.Location = new System.Drawing.Point(24, 356);
            this.GradeList.Name = "GradeList";
            this.GradeList.Size = new System.Drawing.Size(330, 23);
            this.GradeList.TabIndex = 22;
            this.GradeList.SelectedIndexChanged += new System.EventHandler(this.GradeList_SelectedIndexChanged);
            // 
            // Save
            // 
            this.Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Save.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Save.ForeColor = System.Drawing.SystemColors.Control;
            this.Save.Location = new System.Drawing.Point(94, 552);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(185, 47);
            this.Save.TabIndex = 13;
            this.Save.Text = "Įrašyti pažymį";
            this.Save.UseVisualStyleBackColor = false;
            this.Save.Click += new System.EventHandler(this.AddGradeButton_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.textBox4);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(387, 68);
            this.panel5.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Location = new System.Drawing.Point(3, 16);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(360, 38);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Pažymys";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AddGradeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 623);
            this.Controls.Add(this.AddStudentPanel);
            this.Name = "AddGradeForm";
            this.Text = "Pažymio pridėjimas";
            this.Load += new System.EventHandler(this.AddGradeForm_Load_1);
            this.AddStudentPanel.ResumeLayout(false);
            this.AddStudentPanel.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel AddStudentPanel;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox GradeList;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox CommentBox;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textbox;
        private System.Windows.Forms.ComboBox GroupList;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.ComboBox StudentList;
        private System.Windows.Forms.TextBox DateBox;
    }
}