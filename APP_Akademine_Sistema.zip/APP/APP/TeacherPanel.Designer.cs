﻿
namespace APP
{
    partial class TeacherPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.LogOutButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.GroupGrid = new System.Windows.Forms.DataGridView();
            this.Grade_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Teacher_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Group_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Student_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subject_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Student_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Student_Surname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Grade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Comment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.AddGrade = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GroupGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.LogOutButton);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(985, 86);
            this.panel1.TabIndex = 0;
            // 
            // LogOutButton
            // 
            this.LogOutButton.Location = new System.Drawing.Point(856, 29);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(105, 33);
            this.LogOutButton.TabIndex = 5;
            this.LogOutButton.Text = "Atsijungti";
            this.LogOutButton.UseVisualStyleBackColor = true;
            this.LogOutButton.Click += new System.EventHandler(this.LogOutButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dėstytojo valdymo langas";
            // 
            // GroupGrid
            // 
            this.GroupGrid.AllowUserToAddRows = false;
            this.GroupGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GroupGrid.BackgroundColor = System.Drawing.Color.White;
            this.GroupGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GroupGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GroupGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Grade_ID,
            this.Teacher_ID,
            this.Group_ID,
            this.Student_ID,
            this.Subject_ID,
            this.Student_Name,
            this.Student_Surname,
            this.Grade,
            this.Date,
            this.Comment,
            this.Column7,
            this.Column2});
            this.GroupGrid.Location = new System.Drawing.Point(23, 169);
            this.GroupGrid.Name = "GroupGrid";
            this.GroupGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.GroupGrid.RowHeadersVisible = false;
            this.GroupGrid.RowTemplate.Height = 25;
            this.GroupGrid.Size = new System.Drawing.Size(947, 348);
            this.GroupGrid.TabIndex = 1;
            this.GroupGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GroupGrid_CellClick);
            // 
            // Grade_ID
            // 
            this.Grade_ID.DataPropertyName = "Grades_ID";
            this.Grade_ID.HeaderText = "Pažymio_ID";
            this.Grade_ID.Name = "Grade_ID";
            this.Grade_ID.Visible = false;
            // 
            // Teacher_ID
            // 
            this.Teacher_ID.DataPropertyName = "Teacher_ID";
            this.Teacher_ID.HeaderText = "Dėstytojo_ID";
            this.Teacher_ID.Name = "Teacher_ID";
            this.Teacher_ID.Visible = false;
            // 
            // Group_ID
            // 
            this.Group_ID.DataPropertyName = "Group_ID";
            this.Group_ID.HeaderText = "Grupės ID";
            this.Group_ID.Name = "Group_ID";
            this.Group_ID.Visible = false;
            // 
            // Student_ID
            // 
            this.Student_ID.DataPropertyName = "Student_ID";
            this.Student_ID.HeaderText = "Studento ID";
            this.Student_ID.Name = "Student_ID";
            this.Student_ID.Visible = false;
            // 
            // Subject_ID
            // 
            this.Subject_ID.DataPropertyName = "Subject_ID";
            this.Subject_ID.HeaderText = "Dalyko_ID";
            this.Subject_ID.Name = "Subject_ID";
            this.Subject_ID.Visible = false;
            // 
            // Student_Name
            // 
            this.Student_Name.DataPropertyName = "Name";
            this.Student_Name.HeaderText = "Studento vardas";
            this.Student_Name.Name = "Student_Name";
            // 
            // Student_Surname
            // 
            this.Student_Surname.DataPropertyName = "Surname";
            this.Student_Surname.HeaderText = "Studento pavardė";
            this.Student_Surname.Name = "Student_Surname";
            // 
            // Grade
            // 
            this.Grade.DataPropertyName = "Grade";
            this.Grade.HeaderText = "Pažymys";
            this.Grade.Name = "Grade";
            // 
            // Date
            // 
            this.Date.DataPropertyName = "Date";
            this.Date.HeaderText = "Data";
            this.Date.Name = "Date";
            // 
            // Comment
            // 
            this.Comment.DataPropertyName = "Comment";
            this.Comment.HeaderText = "Komentaras";
            this.Comment.Name = "Comment";
            // 
            // Column7
            // 
            this.Column7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column7.HeaderText = "Ištrinti";
            this.Column7.Name = "Column7";
            this.Column7.Text = "Ištrinti";
            this.Column7.UseColumnTextForButtonValue = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "redaguoti";
            this.Column2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column2.HeaderText = "Redaguoti";
            this.Column2.Name = "Column2";
            this.Column2.Text = "Redaguoti";
            this.Column2.UseColumnTextForButtonValue = true;
            // 
            // AddGrade
            // 
            this.AddGrade.FlatAppearance.BorderSize = 0;
            this.AddGrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddGrade.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddGrade.ForeColor = System.Drawing.Color.RoyalBlue;
            this.AddGrade.Location = new System.Drawing.Point(23, 115);
            this.AddGrade.Name = "AddGrade";
            this.AddGrade.Size = new System.Drawing.Size(150, 33);
            this.AddGrade.TabIndex = 3;
            this.AddGrade.Text = "Įvertinti studentą";
            this.AddGrade.UseVisualStyleBackColor = true;
            this.AddGrade.Click += new System.EventHandler(this.AddGrade_Click);
            // 
            // TeacherPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 518);
            this.Controls.Add(this.AddGrade);
            this.Controls.Add(this.GroupGrid);
            this.Controls.Add(this.panel1);
            this.Name = "TeacherPanel";
            this.Text = "Dėstytojo valdymo langas";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GroupGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView GroupGrid;
        private System.Windows.Forms.Button AddGrade;
        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Grade_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Teacher_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_Surname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Grade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Comment;
        private System.Windows.Forms.DataGridViewButtonColumn Column7;
        private System.Windows.Forms.DataGridViewButtonColumn Column2;
    }
}