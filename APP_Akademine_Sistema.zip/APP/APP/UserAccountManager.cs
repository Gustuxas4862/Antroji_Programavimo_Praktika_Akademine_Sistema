﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace APP
{
    class UserAccountManager
    {
        private int dataID, userCount;
        private int personID;
        private MySqlCommand userCommand;
        private MySqlConnection connection;
        Database db = new Database();

        public void AddToDatabase(TextBox name, TextBox surname, TextBox address, TextBox phone, TextBox email, TextBox starting_year, DataType userType)
        {
            int userRoleID = 0;
            Random random = new Random();
            string[] formInputFields;

            if (userType == DataType.Teacher)
            {
                userRoleID = 2;

                formInputFields = new string[5];
                formInputFields[0] = name.Text;
                formInputFields[1] = surname.Text;
                formInputFields[2] = address.Text;
                formInputFields[3] = phone.Text;
                formInputFields[4] = email.Text;
            }
            else
            {
                userRoleID = 3;

                formInputFields = new string[6];
                formInputFields[0] = name.Text;
                formInputFields[1] = surname.Text;
                formInputFields[2] = address.Text;
                formInputFields[3] = phone.Text;
                formInputFields[4] = email.Text;
                formInputFields[5] = starting_year.Text;
            }

            if (InputFieldManager.CheckForEmptyInputFields(formInputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            string username = (name.Text + "." + surname.Text).ToLower().Trim();
            int repeatingUsernameCount = UsernameAvailability(username);
            if (repeatingUsernameCount > 1)
            {
                username = username + repeatingUsernameCount.ToString();
            }

            userCommand = new MySqlCommand("INSERT INTO `users`(`Role_ID`, `Username`, `Password`) VALUES (@roleID, @username, @pass)", connection);
            userCommand.Parameters.Add("@username", MySqlDbType.VarChar).Value = username;
            userCommand.Parameters.Add("@pass", MySqlDbType.VarChar).Value = random.Next(1000, 100000);
            userCommand.Parameters.Add("@roleID", MySqlDbType.Int32).Value = userRoleID;

            if (userCommand.ExecuteNonQuery() == 1)
            {
                int newUserID = GetUserDataID(username);

                if (userType == DataType.Teacher)
                {
                    userCommand.CommandText = "INSERT INTO `teachers`(`User_ID`, `Name`, `Surname`, `Email`, `Phone`, `Address`) VALUES (@userID, @name, @surname, @email, @phone, @address)";
                }
                else
                {
                    userCommand.CommandText = "INSERT INTO `students`(`User_ID`, `Name`, `Surname`, `Email`, `Phone`, `Address`, `Start_Year`) VALUES (@userID, @name, @surname, @email, @phone, @address, @year)";
                    userCommand.Parameters.Add("@year", MySqlDbType.Year).Value = starting_year.Text;
                }

                userCommand.Parameters.Add("@userID", MySqlDbType.Int32).Value = newUserID;
                userCommand.Parameters.Add("@name", MySqlDbType.VarChar).Value = name.Text;
                userCommand.Parameters.Add("@surname", MySqlDbType.VarChar).Value = surname.Text;
                userCommand.Parameters.Add("@email", MySqlDbType.VarChar).Value = email.Text;
                userCommand.Parameters.Add("@address", MySqlDbType.VarChar).Value = address.Text;
                userCommand.Parameters.Add("@phone", MySqlDbType.VarChar).Value = phone.Text;

                userCommand.ExecuteNonQuery();

                MessageBox.Show("Paskyra buvo sėkmingai sukurta");
            }
            else
            {
                MessageBox.Show("Įvyko klaida");
            }

            db.CloseConnectionToDatabase();
        }

        public void AddSubjectToDatabase(string subject_ID, string teacher_ID, string subject_name, string unique_subject_name)
        {
            connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            userCommand = new MySqlCommand("INSERT INTO `subject`(`Subject_Type_ID`, `Teacher_ID`, `Subject_Name`, `Unique_Subject_Name`) VALUES (@SubjectID, @TeacherID, @SubjectName, @UniqueName)", connection);
            userCommand.Parameters.AddWithValue("@SubjectID", Convert.ToInt32(subject_ID));
            userCommand.Parameters.AddWithValue("@TeacherID", Convert.ToInt32(teacher_ID));
            userCommand.Parameters.AddWithValue("@SubjectName", subject_name);
            userCommand.Parameters.AddWithValue("@UniqueName", unique_subject_name);

            if (userCommand.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Dėstytojas sėkmingai priskirtas pasirinktam dalykui");
            }
            else
            {
                MessageBox.Show("Ivyko klaida");
            }

            db.CloseConnectionToDatabase();
        }

        public void AddGroupToDatabase(string student_ID, string user_ID, string subject_ID, string year, string subject_Name)
        {
            string[] inputFields = { year, subject_Name };
            if (InputFieldManager.CheckForEmptyInputFields(inputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            userCommand = new MySqlCommand("INSERT INTO `subject_group`(`Student_ID`, `User_ID`, `Subject_ID`, `Year`, `Subject_Name`) VALUES (@StudentID, @UserID, @SubjectID, @Year, @SubjectName)", connection);
            userCommand.Parameters.AddWithValue("@StudentID", Convert.ToInt32(student_ID));
            userCommand.Parameters.AddWithValue("@UserID", Convert.ToInt32(user_ID));
            userCommand.Parameters.AddWithValue("@SubjectID", Convert.ToInt32(subject_ID));
            userCommand.Parameters.AddWithValue("@Year", Convert.ToInt32(year));
            userCommand.Parameters.AddWithValue("@SubjectName", subject_Name);

            if (userCommand.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Sėkmingai pasirinktai grupei priskirtas studentas");
            }
            else
            {
                MessageBox.Show("Ivyko klaida");
            }

            db.CloseConnectionToDatabase();
        }

        public void AddStudentGradeToDatabase(string subject_ID, string student_ID, string grade, string comment, string subjectID, string time)
        {
            string[] inputFields = { grade, comment };
            if (InputFieldManager.CheckForEmptyInputFields(inputFields))
            {
                MessageBox.Show("Visi duomenų įvesties laukai privalo būti užpildyti.");
                return;
            }

            connection = db.GetConnectionToDatabase();
            db.OpenConnectionToDatabase();

            userCommand = new MySqlCommand("INSERT INTO `grades`(`Group_ID`, `Student_ID`, `Subject_ID`, `Grade`, `Comment`, `Date`) VALUES (@groupID, @studentID, @subjectID, @grade, @comment, @date)", connection);
            userCommand.Parameters.AddWithValue("@groupID", Convert.ToInt32(subject_ID));
            userCommand.Parameters.AddWithValue("@studentID", Convert.ToInt32(student_ID));
            userCommand.Parameters.AddWithValue("@subjectID", Convert.ToInt32(subjectID));
            userCommand.Parameters.AddWithValue("@grade", Convert.ToInt32(grade));
            userCommand.Parameters.AddWithValue("@date", time);
            userCommand.Parameters.AddWithValue("@comment", comment);

            if (userCommand.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Pažymys parašytas");
            }
            else
            {
                MessageBox.Show("Ivyko klaida");
            }

            db.CloseConnectionToDatabase();
        }

        public void TryRemoveFromDatabase(DataGridViewCellEventArgs e, DataGridView grid, AdminPanel adminPanel, TeacherPanel teacherPanel, DataType type, string mainCommand, string updateCommand)
        {
            if (grid.Columns[e.ColumnIndex].HeaderText == "Ištrinti")
            {
                DialogResult confirmationId = MessageBox.Show("Ar tikrai norite ištrinti pasirinktą įrašą?", "Ištrinimas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirmationId == DialogResult.Yes)
                {
                    if (type == DataType.Student)
                    {
                        dataID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["UserID"].Value);
                        personID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Student_ID"].Value);
                    }
                    else if (type == DataType.Teacher)
                    {
                        dataID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["GlobalUserID"].Value);
                        personID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Teacher_ID"].Value);
                    }
                    else if (type == DataType.Subject)
                    {
                        dataID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Subject_ID"].Value);
                    }
                    else if (type == DataType.Group)
                    {
                        dataID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Group_ID"].Value);
                    }
                    else if (type == DataType.Grade)
                    {
                        dataID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Grade_ID"].Value);
                    }

                    MySqlConnection connection = db.GetConnectionToDatabase();
                    db.OpenConnectionToDatabase();

                    try
                    {
                        MySqlCommand command = new MySqlCommand(mainCommand, connection);

                        if (type == DataType.Student)
                        {
                            command.Parameters.AddWithValue("@studentID", personID);
                            command.Parameters.AddWithValue("@id", dataID);
                        }
                        else if (type == DataType.Teacher)
                        {
                            command.Parameters.AddWithValue("@teacherID", personID);
                            command.Parameters.AddWithValue("@id", dataID);
                        }
                        else if (type == DataType.Subject)
                        {
                            command.Parameters.AddWithValue("@subjectID", dataID);
                        }
                        else if (type == DataType.Group)
                        {
                            command.Parameters.AddWithValue("@groupID", dataID);
                        }
                        else if (type == DataType.Grade)
                        {
                            command.Parameters.AddWithValue("@gradeID", dataID);
                        }

                        int executionResult = command.ExecuteNonQuery();

                        if (executionResult > 0)
                        {
                            if (adminPanel == null)
                            {
                                teacherPanel.UpdateGrid(grid, updateCommand);
                            }
                            else
                            {
                                adminPanel.UpdateGrid(grid, updateCommand);
                            }

                            MessageBox.Show("Pasirinktas įrašas buvo sėkmingai ištrintas");
                        }
                        else
                        {
                            MessageBox.Show("Įvyko klaida");
                        }
                    }
                    catch (Exception error)
                    {
                        MessageBox.Show(error.Message);
                    }
                    finally
                    {
                        db.CloseConnectionToDatabase();
                    }
                }
            }
        }

        public void TryEditTableDatabase(DataGridViewCellEventArgs e, DataGridView grid, AdminPanel adminPanel, TeacherPanel teacherPanel, DataType type, string currentTeacherID)
        {
            if (grid.Columns[e.ColumnIndex].HeaderText == "Redaguoti")
            {
                int userID, teacher_ID, subject_type_ID, grades_ID;
                string name, surname, email, phone, address, start_Year, subject_Name, unique_Name, comment, date, grade;

                DataGridViewRow row = grid.Rows[e.RowIndex];
                if (type == DataType.Teacher)
                {
                    userID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Teacher_ID"].Value);
                    name = row.Cells["UserName"].Value.ToString();
                    surname = row.Cells["UserSurname"].Value.ToString();
                    email = row.Cells["EmailAddress"].Value.ToString();
                    address = row.Cells["FullAddress"].Value.ToString();
                    phone = row.Cells["PhoneNumber"].Value.ToString();

                    TeacherDataEditForm editForm = new TeacherDataEditForm(adminPanel, grid, userID, name, surname, email, address, phone);
                    editForm.ShowDialog();
                }
                else if (type == DataType.Student)
                {
                    userID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["UserID"].Value);
                    start_Year = grid.Rows[e.RowIndex].Cells["Start_Year"].Value.ToString();
                    name = row.Cells["Student_Name"].Value.ToString();
                    surname = row.Cells["StudentSurnameData"].Value.ToString();
                    email = row.Cells["Gmail"].Value.ToString();
                    address = row.Cells["StudentAddress"].Value.ToString();
                    phone = row.Cells["StudentPhoneNumber"].Value.ToString();

                    StudentDataEditForm editForm = new StudentDataEditForm(adminPanel, grid, userID, name, surname, email, address, phone, start_Year);
                    editForm.ShowDialog();
                }
                else if (type == DataType.Subject)
                {
                    userID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Subject_ID"].Value);

                    subject_Name = row.Cells["Subject_Name"].Value.ToString();

                    name = row.Cells["Teacher_Name"].Value.ToString();
                    surname = row.Cells["Teacher_Surname"].Value.ToString();

                    subject_type_ID = Convert.ToInt32(row.Cells["Subject_Type_ID"].Value);
                    teacher_ID = Convert.ToInt32(row.Cells["Subject_Teacher_ID"].Value);
                    unique_Name = row.Cells["Unique_Name"].Value.ToString();

                    SubjectDataEditForm editForm = new SubjectDataEditForm(adminPanel, grid, userID, teacher_ID, subject_type_ID, unique_Name, name, surname, subject_Name);
                    editForm.ShowDialog();
                }
                else if (type == DataType.Grade)
                {
                    grades_ID = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Grade_ID"].Value);
                    grade = grid.Rows[e.RowIndex].Cells["Grade"].Value.ToString();
                    comment = grid.Rows[e.RowIndex].Cells["Comment"].Value.ToString();
                    date = grid.Rows[e.RowIndex].Cells["Date"].Value.ToString();

                    StudentGradeEditForm editForm = new StudentGradeEditForm(teacherPanel, grid, grades_ID, Convert.ToInt32(currentTeacherID), grade, comment, date);
                    editForm.ShowDialog();
                }
            }
        }

        private int GetUserDataID(string studentUsername)
        {
            using (userCommand = new MySqlCommand("SELECT * FROM `users` where Username = @usr", connection))
            {
                userCommand.Parameters.Add("@usr", MySqlDbType.VarChar).Value = studentUsername;

                using (MySqlDataReader commandReader = userCommand.ExecuteReader())
                {
                    if (commandReader != null)
                    {
                        commandReader.Read();
                        dataID = Convert.ToInt32(commandReader["Users_ID"]);
                    }
                }
            }

            return dataID;
        }

        private int UsernameAvailability(string username)
        {
            userCount = 0;

            using (MySqlCommand command = new MySqlCommand("SELECT Username FROM users where Username like @usr", connection))
            {
                command.Parameters.AddWithValue("@usr", username + "%");
                using (MySqlDataReader commandReader = command.ExecuteReader())
                {
                    if (commandReader != null)
                    {
                        while (commandReader.Read())
                        {
                            userCount++;
                        }
                    }
                }
            }

            return userCount;
        }
    }

    public enum DataType
    {
        Teacher,
        Student,
        Group,
        Subject,
        Grade
    }
}
