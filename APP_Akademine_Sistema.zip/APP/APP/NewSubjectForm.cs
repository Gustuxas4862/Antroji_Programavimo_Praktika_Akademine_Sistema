﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace APP
{
    public partial class NewSubjectForm : Form
    {
        private string[] subjectInfo;
        private Database db = new Database();
        private AdminPanel adminPanel;
        private DataGridView dataGrid;

        public NewSubjectForm(AdminPanel _adminPanel, DataGridView _dataGrid)
        {
            InitializeComponent();
            adminPanel = _adminPanel;
            dataGrid = _dataGrid;
            subjectInfo = new string[4];

            PopulateLists();
        }

        private void AddSubjectButton_Click(object sender, EventArgs e)
        {
            UserAccountManager userManager = new UserAccountManager();
            userManager.AddSubjectToDatabase(subjectInfo[1], subjectInfo[0], subjectInfo[2], UniqueText.Text);
            adminPanel.UpdateGrid(dataGrid, "SELECT subject.Teacher_ID, subject.Subject_Type_ID, subject.Subject_ID, subject_type.Name as subjectName, teachers.Name, teachers.Surname, " +
                "subject.Unique_Subject_Name from subject INNER JOIN teachers on subject.Teacher_ID = teachers.Teacher_ID inner join subject_type on subject.Subject_Type_ID = subject_type.Subject_Type_ID");
            this.Close();
        }

        private void PopulateLists()
        {
            string query;
            MySqlCommand userCommand;
            MySqlConnection connection;
            MySqlDataReader dataReader;

            connection = db.GetConnectionToDatabase();

            for (int i = 0; i < 2; i++)
            {
                db.OpenConnectionToDatabase();

                query = i == 0 ? "SELECT Teacher_ID, Name, Surname FROM TEACHERS" : "SELECT Subject_Type_ID, Name FROM SUBJECT_TYPE";
                userCommand = new MySqlCommand(query, connection);

                try
                {
                    dataReader = userCommand.ExecuteReader();
                    while (dataReader.Read())
                    {
                        if (i == 0)
                        {
                            if (dataReader.GetString(1) == "Nepaskirta")
                            {
                                TeacherList.Items.Add(dataReader.GetString(0) + " " + dataReader.GetString(1));
                                continue;
                            }
                            TeacherList.Items.Add(dataReader.GetString(0) + " " + dataReader.GetString(1) + " " + dataReader.GetString(2));
                        }
                        else
                        {
                            SubjectList.Items.Add(dataReader.GetString(0) + " " + dataReader.GetString(1));
                        }
                    }
                    dataReader.Close();

                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
                finally
                {
                    db.CloseConnectionToDatabase();
                }
            }
        }

        private void TeacherList_SelectedIndexChanged(object sender, EventArgs e)
        {
            subjectInfo[0] = TeacherList.Text.Split(' ')[0];
        }

        private void SubjectList_SelectedIndexChanged(object sender, EventArgs e)
        {
            MySqlCommand userCommand;
            MySqlConnection connection;
            MySqlDataReader dataReader;

            connection = db.GetConnectionToDatabase();

            string[] subject_info = SplitString(SubjectList.Text);
            string query = "Select Subject_Type_ID, Name from Subject_Type where Subject_Type_ID = " + subject_info[0];
            userCommand = new MySqlCommand(query, connection);

            try
            {
                db.OpenConnectionToDatabase();

                dataReader = userCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    subjectInfo[1] = dataReader.GetString(0);
                    subjectInfo[2] = dataReader.GetString(1);
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                db.CloseConnectionToDatabase();
            }
        }

        private string[] SplitString(string selectedString)
        {
            return selectedString.Split(' ');
        }
    }
}
